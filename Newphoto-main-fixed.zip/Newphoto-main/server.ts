import express from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const DATA_DIR = path.join(__dirname, 'data');
const BOOKS_FILE = path.join(DATA_DIR, 'books.json');

// Ensure data folder and books.json exist
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}
if (!fs.existsSync(BOOKS_FILE)) {
  fs.writeFileSync(BOOKS_FILE, JSON.stringify([]), 'utf-8');
}

// In-memory cache so reads never hit a half-written file
let booksCache: any[] | null = null;

function readBooks(): any[] {
  if (booksCache) return booksCache;
  try {
    const raw = fs.readFileSync(BOOKS_FILE, 'utf-8');
    const parsed = JSON.parse(raw);
    booksCache = Array.isArray(parsed) ? parsed : [];
    return booksCache;
  } catch (err) {
    console.error('Error reading books file:', err);
    // Keep a copy of the unreadable file so no book is ever lost silently
    try {
      if (fs.existsSync(BOOKS_FILE)) {
        fs.copyFileSync(BOOKS_FILE, path.join(DATA_DIR, `books.corrupt-${Date.now()}.json`));
      }
    } catch {}
    booksCache = [];
    return booksCache;
  }
}

function writeBooks(books: any[]) {
  booksCache = books;
  try {
    // Atomic write: write to temp file, then rename (prevents corrupted books.json)
    const tmpFile = `${BOOKS_FILE}.tmp`;
    fs.writeFileSync(tmpFile, JSON.stringify(books, null, 2), 'utf-8');
    fs.renameSync(tmpFile, BOOKS_FILE);
  } catch (err) {
    console.error('Error writing books file:', err);
  }
}

async function startServer() {
  const app = express();
  const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

  // JSON body parser with generous limit for photobook images
  app.use(express.json({ limit: '50mb' }));
  app.use(express.urlencoded({ extended: true, limit: '50mb' }));

  // Shared book links must always show the latest saved book (never a cached copy)
  app.use('/api', (_req, res, next) => {
    res.setHeader('Cache-Control', 'no-store, max-age=0');
    next();
  });

  // API Route: Save or update a book
  app.post('/api/books', (req, res) => {
    try {
      const book = req.body;
      if (!book || !book.id) {
        return res.status(400).json({ error: 'Invalid book payload' });
      }

      const books = readBooks();
      const existingIdx = books.findIndex((b: any) => b.id === book.id);
      if (existingIdx >= 0) {
        books[existingIdx] = { ...book, updatedAt: Date.now() };
      } else {
        books.unshift({ ...book, updatedAt: Date.now() });
      }

      writeBooks(books);
      return res.json({ success: true, book });
    } catch (err) {
      console.error('Error saving book:', err);
      return res.status(500).json({ error: 'Failed to save book' });
    }
  });

  // API Route: Get all books
  app.get('/api/books', (_req, res) => {
    return res.json(readBooks());
  });

  // API Route: Get a specific book by ID (Public preview link)
  app.get('/api/books/:id', (req, res) => {
    try {
      const { id } = req.params;
      const books = readBooks();
      const book = books.find((b: any) => b.id === id);

      if (!book) {
        return res.status(404).json({ error: 'Book not found' });
      }
      return res.json(book);
    } catch (err) {
      console.error('Error fetching book:', err);
      return res.status(500).json({ error: 'Failed to fetch book' });
    }
  });

  // API Route: Delete a book
  app.delete('/api/books/:id', (req, res) => {
    try {
      const { id } = req.params;
      const books = readBooks();
      const filtered = books.filter((b: any) => b.id !== id);
      writeBooks(filtered);
      return res.json({ success: true });
    } catch (err) {
      return res.status(500).json({ error: 'Failed to delete book' });
    }
  });

  // JSON error for oversized / malformed payloads (so the app can show a clear message)
  app.use('/api', (err: any, _req: express.Request, res: express.Response, next: express.NextFunction) => {
    if (err) {
      const status = err.status || err.statusCode || 500;
      return res.status(status).json({ error: err.type === 'entity.too.large' ? 'Book too large' : 'Request failed' });
    }
    next();
  });

  const isProd = process.env.NODE_ENV === 'production';
  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running at http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
