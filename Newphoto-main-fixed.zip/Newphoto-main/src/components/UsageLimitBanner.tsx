import React from 'react';
import { Sparkles, Gift, LogIn, UserPlus } from 'lucide-react';
import { UserProfile, PhotoBook, AppLanguage } from '../types';
import { USAGE_LIMITS, canUserCreateBook } from '../utils/storage';
import { getTranslation } from '../i18n/translations';

interface UsageLimitBannerProps {
  user: UserProfile | null;
  books: PhotoBook[];
  lang: AppLanguage;
  onUpgradePrompt: () => void;
  onClaimBonus: () => void;
  onOpenAuth: () => void;
}

export const UsageLimitBanner: React.FC<UsageLimitBannerProps> = ({
  user,
  books,
  lang,
  onUpgradePrompt,
  onClaimBonus,
  onOpenAuth,
}) => {
  // If user is not logged in yet
  if (!user) {
    return (
      <div className="mx-3 my-2 p-3.5 rounded-2xl bg-gradient-to-r from-indigo-950/70 via-purple-950/50 to-slate-900 border border-indigo-500/30 shadow-md flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-indigo-600/30 text-indigo-300 flex items-center justify-center font-bold">
            <Sparkles className="w-4 h-4 text-yellow-400" />
          </div>
          <div>
            <h4 className="text-xs font-bold text-white">Naya Account Banayein</h4>
            <p className="text-[11px] text-indigo-200">
              Sign Up karte hi <strong>2 Free Photobooks</strong> unlock hongi!
            </p>
          </div>
        </div>
        <button
          onClick={onOpenAuth}
          className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-md shadow-indigo-600/30 active:scale-95 transition shrink-0"
        >
          <UserPlus className="w-3.5 h-3.5" />
          <span>Sign Up</span>
        </button>
      </div>
    );
  }

  const isPro = user.tier === 'pro';
  const { remaining } = canUserCreateBook(user, books);
  const totalFreeAllowed = USAGE_LIMITS.maxFreeBooks + (user.bonusCredits || 0);
  const usedCount = books.length;
  const percentage = Math.min(100, Math.round((usedCount / totalFreeAllowed) * 100));

  if (isPro) {
    return (
      <div className="mx-3 my-2 p-3 rounded-2xl bg-gradient-to-r from-amber-500/15 via-yellow-500/10 to-amber-600/15 border border-yellow-500/30 flex items-center justify-between text-xs text-amber-200 shadow-sm">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-yellow-500/20 text-yellow-400 flex items-center justify-center font-bold">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <p className="font-bold text-yellow-300">{getTranslation(lang, 'proPlan')}</p>
            <p className="text-[11px] text-amber-300/80">Unlimited photobooks & HD exports unlocked</p>
          </div>
        </div>
        <span className="px-2 py-0.5 rounded-full bg-yellow-400/20 text-yellow-300 text-[10px] font-bold border border-yellow-400/40">
          PRO VIP
        </span>
      </div>
    );
  }

  return (
    <div className="mx-3 my-2 p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-md">
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <h4 className="text-xs font-bold text-slate-200 tracking-wide uppercase">
            {getTranslation(lang, 'freePlan')} • {usedCount}/{totalFreeAllowed} {getTranslation(lang, 'booksUsed')}
          </h4>
        </div>
        <span className={`text-[11px] font-bold px-2 py-0.5 rounded-full ${
          remaining > 0
            ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
            : 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
        }`}>
          {remaining > 0 ? `${remaining} Free Left` : 'Limit Reached'}
        </span>
      </div>

      {/* Progress Bar */}
      <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden mb-2">
        <div
          className={`h-full rounded-full transition-all duration-500 ${
            percentage >= 100
              ? 'bg-gradient-to-r from-amber-500 to-rose-500'
              : 'bg-gradient-to-r from-indigo-500 to-purple-500'
          }`}
          style={{ width: `${percentage}%` }}
        />
      </div>

      <div className="flex items-center justify-between text-[11px] text-slate-400">
        <span>Max {USAGE_LIMITS.maxPagesPerBook} pages per book</span>
        {remaining === 0 ? (
          <button
            onClick={onClaimBonus}
            className="flex items-center gap-1 text-pink-400 font-semibold hover:underline"
          >
            <Gift className="w-3 h-3" /> +1 Free Book
          </button>
        ) : (
          <button
            onClick={onUpgradePrompt}
            className="text-indigo-400 font-semibold hover:underline"
          >
            Go Unlimited
          </button>
        )}
      </div>
    </div>
  );
};
