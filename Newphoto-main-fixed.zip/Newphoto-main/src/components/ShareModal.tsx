import React, { useState, useEffect } from 'react';
import { 
  X, 
  Copy, 
  Check, 
  Share2, 
  Send, 
  Smartphone, 
  Eye, 
  Download,
  Sparkles,
  Loader2,
  AlertCircle,
  RefreshCw
} from 'lucide-react';
import { PhotoBook, AppLanguage } from '../types';
import { getTranslation } from '../i18n/translations';
import { syncBookToServer } from '../utils/storage';

interface ShareModalProps {
  book: PhotoBook;
  lang: AppLanguage;
  onClose: () => void;
  onOpenPreview: () => void;
}

export const ShareModal: React.FC<ShareModalProps> = ({
  book,
  lang,
  onClose,
  onOpenPreview,
}) => {
  const [copied, setCopied] = useState(false);
  // 'syncing' -> book is being saved on the server; link is only shared once it is 'ok'
  const [syncState, setSyncState] = useState<'syncing' | 'ok' | 'error'>('syncing');
  const [syncAttempt, setSyncAttempt] = useState(0);

  // Generate public preview-only share link
  const origin = typeof window !== 'undefined' ? window.location.origin : '';
  const pathname = typeof window !== 'undefined' ? window.location.pathname : '';
  const shareUrl = `${origin}${pathname}?share=${encodeURIComponent(book.id)}`;

  useEffect(() => {
    // Ensure book is synced to server so anyone opening the link can view it
    let cancelled = false;
    setSyncState('syncing');
    syncBookToServer(book, 3).then((ok) => {
      if (!cancelled) setSyncState(ok ? 'ok' : 'error');
    });
    return () => {
      cancelled = true;
    };
  }, [book, syncAttempt]);

  const isReady = syncState === 'ok';

  const handleCopy = async () => {
    if (!isReady) return;
    try {
      await navigator.clipboard.writeText(shareUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch {
      // Fallback
    }
  };

  const handleNativeShare = async () => {
    if (!isReady) return;
    if (navigator.share) {
      try {
        await navigator.share({
          title: book.title,
          text: `Check out my photobook "${book.title}" created with PhotoBook App!`,
          url: shareUrl,
        });
      } catch {
        // User cancelled
      }
    } else {
      handleCopy();
    }
  };

  const shareToWhatsApp = () => {
    if (!isReady) return;
    const text = encodeURIComponent(
      `📖 Take a look at my photobook "${book.title}"!\n\nOpen link to flip through: ${shareUrl}\n\nSign up or log in to create your own free photobook!`
    );
    window.open(`https://api.whatsapp.com/send?text=${text}`, '_blank');
  };

  const shareToTelegram = () => {
    if (!isReady) return;
    const text = encodeURIComponent(`Check out my photobook "${book.title}": ${shareUrl}`);
    window.open(`https://t.me/share/url?url=${encodeURIComponent(shareUrl)}&text=${text}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex flex-col justify-end sm:items-center sm:justify-center p-3 animate-in fade-in">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-md p-5 shadow-2xl flex flex-col gap-4">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-indigo-600/30 text-indigo-400 flex items-center justify-center">
              <Share2 className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">Share Photobook</h3>
              <p className="text-[11px] text-slate-400 truncate max-w-[240px]">{book.title}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-slate-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Explain how recipient experiences it */}
        <div className="bg-indigo-950/40 border border-indigo-500/30 rounded-2xl p-3 text-xs text-indigo-200 flex items-start gap-2.5">
          <Eye className="w-4 h-4 text-indigo-400 shrink-0 mt-0.5" />
          <p className="leading-relaxed text-[11px]">
            <strong>Preview Mode:</strong> WhatsApp link par click karne se dost seedha aapka photobook flip karke dekh sakega. Wahan se woh <strong>Sign Up ya Log In</strong> karke apna khud ka photobook bana sakte hain!
          </p>
        </div>

        {/* Sync status: link works for everyone only after the book is saved online */}
        {syncState === 'syncing' && (
          <div className="flex items-center gap-2 text-[11px] text-indigo-200 bg-indigo-950/40 border border-indigo-500/30 rounded-xl px-3 py-2">
            <Loader2 className="w-3.5 h-3.5 animate-spin text-indigo-400" />
            <span>Link ready ho raha hai... book online save ho rahi hai</span>
          </div>
        )}
        {syncState === 'error' && (
          <div className="flex items-center justify-between gap-2 text-[11px] text-amber-200 bg-amber-950/40 border border-amber-500/30 rounded-xl px-3 py-2">
            <span className="flex items-center gap-2">
              <AlertCircle className="w-3.5 h-3.5 text-amber-400 shrink-0" />
              <span>Book online save nahi ho paayi. Internet check karke dobara try karein.</span>
            </span>
            <button
              onClick={() => setSyncAttempt((n) => n + 1)}
              className="shrink-0 flex items-center gap-1 px-2 py-1 rounded-lg bg-amber-600 text-white font-bold"
            >
              <RefreshCw className="w-3 h-3" />
              <span>Retry</span>
            </button>
          </div>
        )}

        {/* Share Link Input Box */}
        <div className="flex items-center gap-2 bg-slate-950 border border-slate-800 rounded-2xl p-1.5 pl-3">
          <input
            type="text"
            readOnly
            value={shareUrl}
            className="flex-1 bg-transparent text-xs text-slate-300 outline-none truncate"
          />
          <button
            onClick={handleCopy}
            disabled={!isReady}
            className={`flex items-center gap-1 px-3 py-1.5 rounded-xl font-bold text-xs transition disabled:opacity-40 disabled:cursor-not-allowed ${
              copied
                ? 'bg-emerald-600 text-white'
                : 'bg-indigo-600 text-white hover:bg-indigo-500'
            }`}
          >
            {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copied!' : 'Copy'}</span>
          </button>
        </div>

        {/* Quick App Buttons (WhatsApp, Telegram, Android Share) */}
        <div className="grid grid-cols-3 gap-2">
          <button
            onClick={shareToWhatsApp}
            disabled={!isReady}
            className="disabled:opacity-40 disabled:cursor-not-allowed flex flex-col items-center justify-center gap-1.5 p-3 rounded-2xl bg-emerald-950/40 hover:bg-emerald-900/50 border border-emerald-500/30 text-emerald-300 text-xs font-semibold active:scale-95 transition"
          >
            <div className="w-8 h-8 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
              💬
            </div>
            <span>WhatsApp</span>
          </button>

          <button
            onClick={shareToTelegram}
            disabled={!isReady}
            className="disabled:opacity-40 disabled:cursor-not-allowed flex flex-col items-center justify-center gap-1.5 p-3 rounded-2xl bg-sky-950/40 hover:bg-sky-900/50 border border-sky-500/30 text-sky-300 text-xs font-semibold active:scale-95 transition"
          >
            <div className="w-8 h-8 rounded-full bg-sky-500/20 text-sky-400 flex items-center justify-center">
              <Send className="w-4 h-4" />
            </div>
            <span>Telegram</span>
          </button>

          <button
            onClick={handleNativeShare}
            disabled={!isReady}
            className="disabled:opacity-40 disabled:cursor-not-allowed flex flex-col items-center justify-center gap-1.5 p-3 rounded-2xl bg-purple-950/40 hover:bg-purple-900/50 border border-purple-500/30 text-purple-300 text-xs font-semibold active:scale-95 transition"
          >
            <div className="w-8 h-8 rounded-full bg-purple-500/20 text-purple-400 flex items-center justify-center">
              <Smartphone className="w-4 h-4" />
            </div>
            <span>More Apps</span>
          </button>
        </div>

        {/* Test Link Button */}
        <button
          onClick={onOpenPreview}
          className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold flex items-center justify-center gap-1.5 transition"
        >
          <Eye className="w-3.5 h-3.5 text-indigo-400" />
          <span>Test Receiver Preview Experience</span>
        </button>
      </div>
    </div>
  );
};
