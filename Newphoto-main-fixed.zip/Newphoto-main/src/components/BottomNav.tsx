import React from 'react';
import { Home, BookOpen, Sparkles, User } from 'lucide-react';
import { AppTab, AppLanguage } from '../types';
import { getTranslation } from '../i18n/translations';

interface BottomNavProps {
  currentTab: AppTab;
  onTabChange: (tab: AppTab) => void;
  lang: AppLanguage;
  booksCount: number;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  currentTab,
  onTabChange,
  lang,
  booksCount,
}) => {
  const tabs = [
    { id: 'home' as AppTab, label: getTranslation(lang, 'home'), icon: Home },
    {
      id: 'books' as AppTab,
      label: getTranslation(lang, 'myBooks'),
      icon: BookOpen,
      badge: booksCount > 0 ? booksCount : undefined,
    },
    { id: 'templates' as AppTab, label: getTranslation(lang, 'templates'), icon: Sparkles },
    { id: 'profile' as AppTab, label: getTranslation(lang, 'profile'), icon: User },
  ];

  return (
    <nav className="shrink-0 sticky bottom-0 z-40 w-full bg-slate-950/98 backdrop-blur-xl border-t border-slate-800/80 px-2 py-1.5 pb-safe shadow-2xl select-none">
      <div className="flex items-center justify-around max-w-md mx-auto">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = currentTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id)}
              className="flex flex-col items-center justify-center flex-1 py-1 relative group transition-all"
            >
              {/* Material 3 active pill background */}
              <div
                className={`flex items-center justify-center w-14 h-8 rounded-full transition-all duration-200 ${
                  isActive
                    ? 'bg-indigo-600/30 text-indigo-300 ring-1 ring-indigo-500/40 shadow-inner'
                    : 'text-slate-400 group-hover:text-slate-200'
                }`}
              >
                <div className="relative">
                  <Icon className={`w-5 h-5 ${isActive ? 'stroke-[2.4px]' : 'stroke-2'}`} />
                  {tab.badge !== undefined && (
                    <span className="absolute -top-1.5 -right-2.5 px-1 min-w-4 h-4 bg-pink-500 text-white text-[9px] font-black rounded-full flex items-center justify-center shadow-sm">
                      {tab.badge}
                    </span>
                  )}
                </div>
              </div>
              <span
                className={`text-[10px] mt-0.5 tracking-tight transition-colors ${
                  isActive ? 'font-bold text-indigo-300' : 'font-medium text-slate-400'
                }`}
              >
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
