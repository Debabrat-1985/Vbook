import React, { useState, useEffect, useRef } from 'react';
import { 
  ChevronLeft, 
  ChevronRight, 
  Volume2, 
  VolumeX, 
  Maximize, 
  Minimize, 
  Share2, 
  Edit3, 
  Sparkles, 
  BookOpen, 
  LogIn, 
  Heart,
  ZoomIn,
  X,
  ArrowLeft
} from 'lucide-react';
import { PhotoBook, AppLanguage, BookPage } from '../types';
import { THEME_CONFIGS } from '../utils/themePresets';
import { soundEffects } from '../utils/audio';
import { getTranslation } from '../i18n/translations';
import { PageLayoutRenderer } from './PageLayoutRenderer';

interface FlipBookViewerProps {
  book: PhotoBook;
  isSharedPreview?: boolean;
  lang: AppLanguage;
  onBack?: () => void;
  onEdit?: () => void;
  onShare?: () => void;
  onStartCreate?: () => void;
  onOpenAuth?: (mode: 'signup' | 'login') => void;
  onLanguageChange?: (lang: AppLanguage) => void;
  isLoggedIn?: boolean;
}

// Every page is drawn on a fixed-size "design canvas" and then scaled to fit the screen,
// so the book looks exactly the same on every phone / browser / WhatsApp in-app browser.
const STAGE_WIDTH = 360;
const FLIP_DURATION_MS = 720;

export const FlipBookViewer: React.FC<FlipBookViewerProps> = ({
  book,
  isSharedPreview = false,
  lang,
  onBack,
  onEdit,
  onShare,
  onStartCreate,
  onOpenAuth,
  isLoggedIn = false,
}) => {
  const [currentPageIndex, setCurrentPageIndex] = useState(0);
  const [isSoundEnabled, setIsSoundEnabled] = useState(true);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [zoomedPhoto, setZoomedPhoto] = useState<string | null>(null);
  const [flipDirection, setFlipDirection] = useState<'next' | 'prev' | null>(null);
  const [isAnimating, setIsAnimating] = useState(false);
  const [flipTarget, setFlipTarget] = useState<number | null>(null);
  const flipTimerRef = useRef<number | null>(null);

  const containerRef = useRef<HTMLDivElement>(null);
  const canvasContainerRef = useRef<HTMLDivElement>(null);
  const touchStartX = useRef<number | null>(null);

  // Dynamic responsive sizing to strictly fit available space without vertical/horizontal overflow
  const [pageSize, setPageSize] = useState<{ width: number; height: number }>({ width: 320, height: 430 });

  const themeConfig = THEME_CONFIGS[book.theme] || THEME_CONFIGS['classic-linen'];
  const pages = book.pages || [];
  const totalPages = pages.length;
  const currentPage: BookPage | undefined = pages[currentPageIndex];

  // Mathematical fit calculation: fits entire book page inside screen so Edit/Share and Prev/Next never get cut off
  useEffect(() => {
    const updateDimensions = () => {
      if (!canvasContainerRef.current) return;
      const { clientWidth, clientHeight } = canvasContainerRef.current;
      if (clientWidth <= 0 || clientHeight <= 0) return;

      const padX = 20; // 10px each side
      const padY = 16; // 8px top and bottom
      const maxW = Math.max(140, clientWidth - padX);
      const maxH = Math.max(180, clientHeight - padY);

      // Book aspect ratio (width : height = 1 : 1.34)
      const targetRatio = 1 / 1.34;
      let calculatedW = maxH * targetRatio;
      let calculatedH = maxH;

      if (calculatedW > maxW) {
        calculatedW = maxW;
        calculatedH = calculatedW / targetRatio;
      }

      // Max width threshold for tablets/desktop so it looks like an elegant handheld book
      if (calculatedW > 420) {
        calculatedW = 420;
        calculatedH = calculatedW / targetRatio;
      }

      setPageSize({
        width: Math.floor(calculatedW),
        height: Math.floor(calculatedH),
      });
    };

    updateDimensions();

    const resizeObserver = new ResizeObserver(() => {
      updateDimensions();
    });

    if (canvasContainerRef.current) {
      resizeObserver.observe(canvasContainerRef.current);
    }
    window.addEventListener('resize', updateDimensions);

    return () => {
      resizeObserver.disconnect();
      window.removeEventListener('resize', updateDimensions);
    };
  }, []);

  // Sound toggle
  const toggleSound = () => {
    setIsSoundEnabled(prev => !prev);
  };

  useEffect(() => {
    return () => {
      if (flipTimerRef.current) window.clearTimeout(flipTimerRef.current);
    };
  }, []);

  // Real book page turn: the page lifts from the spine, turns over and shows the next page underneath
  const turnToIndex = (idx: number) => {
    if (isAnimating || idx === currentPageIndex || idx < 0 || idx > totalPages - 1) return;
    const dir: 'next' | 'prev' = idx > currentPageIndex ? 'next' : 'prev';
    setIsAnimating(true);
    setFlipDirection(dir);
    setFlipTarget(idx);
    if (isSoundEnabled) soundEffects.playPageTurn();

    flipTimerRef.current = window.setTimeout(() => {
      setCurrentPageIndex(idx);
      setFlipDirection(null);
      setFlipTarget(null);
      setIsAnimating(false);
      flipTimerRef.current = null;
    }, FLIP_DURATION_MS);
  };

  // Turn page forward (Next) with 3D palti animation
  const turnNext = () => turnToIndex(currentPageIndex + 1);

  // Turn page backward (Prev) with 3D palti animation
  const turnPrev = () => turnToIndex(currentPageIndex - 1);

  // Touch Swipe handlers for mobile
  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartX.current = e.touches[0].clientX;
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    if (touchStartX.current === null) return;
    const touchEndX = e.changedTouches[0].clientX;
    const diff = touchStartX.current - touchEndX;

    if (Math.abs(diff) > 36) {
      if (diff > 0) {
        turnNext();
      } else {
        turnPrev();
      }
    }
    touchStartX.current = null;
  };

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowRight' || e.key === ' ') {
        turnNext();
      } else if (e.key === 'ArrowLeft') {
        turnPrev();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [currentPageIndex, totalPages, isAnimating]);

  const toggleFullscreenMode = () => {
    if (!document.fullscreenElement) {
      containerRef.current?.requestFullscreen?.().catch(() => {});
      setIsFullscreen(true);
    } else {
      document.exitFullscreen?.().catch(() => {});
      setIsFullscreen(false);
    }
  };

  if (!currentPage) {
    return (
      <div className="flex-1 flex items-center justify-center p-6 text-center text-slate-400">
        No pages in this photobook yet.
      </div>
    );
  }

  const isCover = currentPage.layout === 'cover';
  const isBackCover = currentPage.layout === 'back-cover';

  // Draws ONE page of the book (theme + layout + photos) on the fixed design canvas, scaled to fit
  const renderPageSurface = (page: BookPage, interactive: boolean) => {
    const pageIsCover = page.layout === 'cover';
    const pageIsBack = page.layout === 'back-cover';
    const border = pageIsCover || pageIsBack ? 4 : 1;
    const innerW = Math.max(1, pageSize.width - border * 2);
    const innerH = Math.max(1, pageSize.height - border * 2);
    const scale = innerW / STAGE_WIDTH;
    const stageHeight = Math.round((STAGE_WIDTH * innerH) / innerW);

    return (
      <div
        className={`w-full h-full rounded-2xl shadow-2xl overflow-hidden relative ${
          pageIsCover || pageIsBack
            ? `${themeConfig.coverBg} ${themeConfig.coverText} border-4 border-amber-400/20`
            : `${themeConfig.pageBg} paper-texture border border-slate-300/40`
        }`}
      >
        {/* Fixed-size design canvas (scaled) so layouts never shift between devices */}
        <div
          style={{
            position: 'absolute',
            top: 0,
            left: 0,
            width: `${STAGE_WIDTH}px`,
            height: `${stageHeight}px`,
            transform: `scale(${scale})`,
            transformOrigin: 'top left',
          }}
          className="flex flex-col justify-between"
        >
          {/* PAGE CONTENT RENDERING FOR ALL 30 ADVANCED SHAPES & LAYOUTS */}
          <PageLayoutRenderer
            page={page}
            themeConfig={themeConfig}
            onPhotoClick={interactive ? (url) => setZoomedPhoto(url) : undefined}
            isCover={pageIsCover}
            isBackCover={pageIsBack}
            bookTitle={book.title}
            authorName={book.authorName}
          />
        </div>

        {/* Book Spine Crease Gradient on left edge */}
        <div className="absolute left-0 top-0 bottom-0 w-5 bg-gradient-to-r from-black/25 via-black/10 to-transparent pointer-events-none z-20" />
        {/* Book Right Edge Turn Highlight */}
        <div className="absolute right-0 top-0 bottom-0 w-2.5 bg-gradient-to-l from-black/15 to-transparent pointer-events-none z-20" />

        {interactive && (
          <>
            {/* Left Page Turn Click Target */}
            <div
              onClick={turnPrev}
              className="absolute left-0 top-0 bottom-0 w-14 cursor-pointer z-30 opacity-0 hover:opacity-100 flex items-center pl-2 group"
              title="Previous Page"
            >
              {currentPageIndex > 0 && (
                <div className="w-7 h-7 rounded-full bg-black/60 backdrop-blur-xs text-white flex items-center justify-center shadow-lg group-hover:scale-105 transition-transform">
                  <ChevronLeft className="w-4 h-4" />
                </div>
              )}
            </div>

            {/* Right Page Turn Click Target */}
            <div
              onClick={turnNext}
              className="absolute right-0 top-0 bottom-0 w-14 cursor-pointer z-30 opacity-0 hover:opacity-100 flex items-center justify-end pr-2 group"
              title="Next Page"
            >
              {currentPageIndex < totalPages - 1 && (
                <div className="w-7 h-7 rounded-full bg-black/60 backdrop-blur-xs text-white flex items-center justify-center shadow-lg group-hover:scale-105 transition-transform">
                  <ChevronRight className="w-4 h-4" />
                </div>
              )}
            </div>
          </>
        )}
      </div>
    );
  };

  return (
    <div
      ref={containerRef}
      className="h-full w-full flex flex-col justify-between overflow-hidden relative bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 select-none"
    >
      {/* 1. TOP HEADER - PINNED & COMPACT (Edit & Share buttons stay 100% visible) */}
      {isSharedPreview ? (
        <div className="shrink-0 z-30 bg-gradient-to-r from-indigo-900/95 via-purple-900/95 to-pink-900/95 border-b border-indigo-500/30 px-3 py-2 text-white flex items-center justify-between text-xs backdrop-blur-md shadow-md">
          <div className="flex items-center gap-2 truncate">
            {onBack && (
              <button
                onClick={onBack}
                className="p-1 -ml-1 rounded-full text-white/80 hover:text-white hover:bg-white/10 active:scale-95 transition"
                title="Go Back"
              >
                <ArrowLeft className="w-4 h-4" />
              </button>
            )}
            <span className="p-1 rounded-lg bg-white/20 text-yellow-300">
              <Sparkles className="w-3.5 h-3.5" />
            </span>
            <div className="truncate">
              <p className="font-bold text-[12px] truncate">{book.title}</p>
              <p className="text-[10px] text-indigo-200">
                {getTranslation(lang, 'sharedBy', { author: book.authorName || 'User' })}
              </p>
            </div>
          </div>
          <div className="shrink-0 flex items-center gap-1.5">
            {isLoggedIn ? (
              <button
                onClick={() => onStartCreate?.()}
                className="flex items-center gap-1 px-3 py-1 rounded-full bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-[11px] shadow-sm shadow-indigo-600/30 active:scale-95 transition"
              >
                <Sparkles className="w-3 h-3 text-yellow-300" />
                <span>Create My Book</span>
              </button>
            ) : (
              <>
                <button
                  onClick={() => onOpenAuth ? onOpenAuth('login') : onStartCreate?.()}
                  className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-slate-900/80 hover:bg-slate-900 text-slate-100 font-semibold text-[11px] border border-white/20 transition active:scale-95"
                >
                  <LogIn className="w-3 h-3 text-indigo-400" />
                  <span>Login</span>
                </button>
                <button
                  onClick={() => onOpenAuth ? onOpenAuth('signup') : onStartCreate?.()}
                  className="flex items-center gap-1 px-3 py-1 rounded-full bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-[11px] shadow-sm shadow-indigo-600/30 active:scale-95 transition"
                >
                  <span>Sign Up</span>
                </button>
              </>
            )}
          </div>
        </div>
      ) : (
        /* Unified Author Header with Back, Title, Edit and Share */
        <div className="shrink-0 z-30 px-3 py-2 flex items-center justify-between text-xs text-slate-300 bg-slate-950/95 backdrop-blur-md border-b border-white/10 shadow-sm">
          <div className="flex items-center gap-2 min-w-0">
            {onBack && (
              <button
                onClick={onBack}
                className="p-1.5 -ml-1 rounded-full text-slate-300 hover:text-white hover:bg-slate-850 active:scale-95 transition"
                title="Go Back"
              >
                <ArrowLeft className="w-4 h-4" />
              </button>
            )}
            <BookOpen className="w-4 h-4 text-indigo-400 shrink-0" />
            <div className="min-w-0">
              <h2 className="font-bold text-slate-100 truncate text-xs sm:text-sm">{book.title}</h2>
              <p className="text-[10px] text-slate-400 truncate">
                {themeConfig.name} • {totalPages} {lang === 'hindi' ? 'पेज' : 'Pages'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            {onEdit && (
              <button
                onClick={onEdit}
                className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-slate-800 text-slate-200 hover:bg-slate-700 hover:text-white text-[11px] font-semibold border border-slate-700/80 transition active:scale-95 shadow-xs"
                title="Edit this Photobook"
              >
                <Edit3 className="w-3.5 h-3.5 text-indigo-400" />
                <span>Edit</span>
              </button>
            )}
            {onShare && (
              <button
                onClick={onShare}
                className="flex items-center gap-1 px-3 py-1 rounded-full bg-gradient-to-r from-indigo-600 to-pink-600 text-white hover:opacity-95 text-[11px] font-bold transition shadow-sm shadow-indigo-600/30 active:scale-95"
                title="Share Photobook"
              >
                <Share2 className="w-3.5 h-3.5" />
                <span>Share</span>
              </button>
            )}
          </div>
        </div>
      )}

      {/* 2. MAIN 3D FLIPBOOK CANVAS - AUTO-FITTED (Never exceeds screen height, NO SCROLL) */}
      <div 
        ref={canvasContainerRef}
        className="flex-1 min-h-0 min-w-0 w-full flex items-center justify-center p-2 relative select-none overflow-hidden my-auto"
        onTouchStart={handleTouchStart}
        onTouchEnd={handleTouchEnd}
      >
        {/* Flipbook Physical Shadow & Shell - Mathematically exact bounded sizing */}
        <div 
          style={{ width: `${pageSize.width}px`, height: `${pageSize.height}px` }}
          className="relative shrink-0 flex flex-col items-center justify-center transition-all duration-200 my-auto"
        >
          {/* Subtle Book 3D Spine Thickness depth on left side */}
          <div 
            className="absolute -left-2 top-0.5 bottom-0.5 w-2 rounded-l-md shadow-2xl opacity-80"
            style={{ backgroundColor: themeConfig.spineColor }}
          />

          <div className="absolute inset-0 leaf-stage">
            {flipDirection && flipTarget !== null && pages[flipTarget] ? (
              <>
                {/* Page underneath (revealed while the leaf turns) */}
                <div className="absolute inset-0">
                  {renderPageSurface(flipDirection === 'next' ? pages[flipTarget] : currentPage, false)}
                  <div
                    className={`absolute inset-0 rounded-2xl bg-black pointer-events-none z-30 ${
                      flipDirection === 'next' ? 'leaf-cast-next' : 'leaf-cast-prev'
                    }`}
                  />
                </div>

                {/* The turning leaf: front = page being lifted, back = plain paper */}
                <div className={`leaf ${flipDirection === 'next' ? 'leaf-turn-next' : 'leaf-turn-prev'}`}>
                  <div className="leaf-face">
                    {renderPageSurface(flipDirection === 'next' ? currentPage : pages[flipTarget], false)}
                  </div>
                  <div className="leaf-face leaf-face-back">
                    <div className={`w-full h-full rounded-2xl overflow-hidden relative shadow-2xl ${themeConfig.pageBg} paper-texture border border-slate-300/40`}>
                      <div className="absolute inset-0 bg-gradient-to-l from-black/20 via-black/5 to-transparent" />
                    </div>
                  </div>
                </div>
              </>
            ) : (
              <div key={`flip-page-${currentPage.id}`} className="absolute inset-0">
                {renderPageSurface(currentPage, true)}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* 3. BOTTOM CONTROL BAR - PINNED & ALWAYS VISIBLE (Prev, Page 1 of 3, Next never cut off) */}
      <div className="shrink-0 z-30 px-3 py-1.5 pb-safe bg-slate-950/95 backdrop-blur-md border-t border-white/10 shadow-2xl flex flex-col gap-1">
        <div className="flex items-center justify-between max-w-sm mx-auto w-full">
          {/* Previous Page Button */}
          <button
            onClick={turnPrev}
            disabled={currentPageIndex === 0 || isAnimating}
            className={`flex items-center gap-1 px-3 py-1.5 rounded-full text-xs font-semibold transition ${
              currentPageIndex === 0
                ? 'opacity-30 cursor-not-allowed text-slate-500 bg-slate-900'
                : 'bg-slate-800 text-slate-200 hover:bg-slate-700 active:scale-95'
            }`}
          >
            <ChevronLeft className="w-4 h-4" />
            <span>Prev</span>
          </button>

          {/* Current Page Indicator & Quick Actions */}
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-slate-200 bg-slate-900 border border-slate-800 px-2.5 py-0.5 rounded-full">
              {getTranslation(lang, 'pageOf', {
                current: currentPageIndex + 1,
                total: totalPages,
              })}
            </span>
            <button
              onClick={toggleSound}
              className={`p-1 rounded-full transition ${
                isSoundEnabled ? 'text-indigo-400 bg-indigo-500/10' : 'text-slate-500'
              }`}
              title={isSoundEnabled ? 'Sound On' : 'Sound Off'}
            >
              {isSoundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            </button>
            <button
              onClick={toggleFullscreenMode}
              className="p-1 rounded-full text-slate-400 hover:text-white transition"
              title="Fullscreen"
            >
              {isFullscreen ? <Minimize className="w-4 h-4" /> : <Maximize className="w-4 h-4" />}
            </button>
          </div>

          {/* Next Page Button */}
          <button
            onClick={turnNext}
            disabled={currentPageIndex === totalPages - 1 || isAnimating}
            className={`flex items-center gap-1 px-3 py-1.5 rounded-full text-xs font-semibold transition ${
              currentPageIndex === totalPages - 1
                ? 'opacity-30 cursor-not-allowed text-slate-500 bg-slate-900'
                : 'bg-indigo-600 text-white hover:bg-indigo-500 shadow-md shadow-indigo-600/30 active:scale-95'
            }`}
          >
            <span>Next</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        {/* Thumbnail Page Dots & Flip Hint */}
        <div className="flex items-center justify-between max-w-sm mx-auto w-full px-1">
          <span className="text-[10px] text-slate-500">👈 Palti / Swipe</span>
          <div className="flex items-center justify-center gap-1.5 overflow-x-auto py-0.5">
            {pages.map((p, idx) => (
              <button
                key={p.id}
                onClick={() => turnToIndex(idx)}
                className={`h-1.5 rounded-full transition-all ${
                  idx === currentPageIndex
                    ? 'w-5 bg-indigo-400'
                    : 'w-1.5 bg-slate-700 hover:bg-slate-500'
                }`}
                title={`Page ${idx + 1}`}
              />
            ))}
          </div>
          <span className="text-[10px] text-slate-500">Tap edge 👉</span>
        </div>

        {/* SHARED PREVIEW COMPACT CTA DRAWER */}
        {isSharedPreview && (
          <div className="mt-0.5 p-2 rounded-xl bg-gradient-to-r from-indigo-900/60 via-purple-900/60 to-pink-900/60 border border-indigo-500/40 shadow-sm flex items-center justify-between gap-2 max-w-sm mx-auto w-full">
            <div className="min-w-0">
              <h4 className="text-[11px] font-bold text-white truncate">
                {getTranslation(lang, 'makeYourOwnBook')}
              </h4>
              <p className="text-[9px] text-indigo-200 truncate">
                2 Free Photobooks on Sign Up
              </p>
            </div>

            <div className="flex items-center gap-1.5 shrink-0">
              {isLoggedIn ? (
                <button
                  onClick={() => onStartCreate?.()}
                  className="py-1 px-2.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-[11px] shadow-sm active:scale-95 transition"
                >
                  Create My Book
                </button>
              ) : (
                <>
                  <button
                    onClick={() => onOpenAuth ? onOpenAuth('signup') : onStartCreate?.()}
                    className="py-1 px-2.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-[11px] shadow-sm active:scale-95 transition"
                  >
                    Sign Up
                  </button>
                  <button
                    onClick={() => onOpenAuth ? onOpenAuth('login') : onStartCreate?.()}
                    className="py-1 px-2.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-indigo-400/40 text-slate-100 font-bold text-[11px] active:scale-95 transition"
                  >
                    Log In
                  </button>
                </>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Photo Zoom Modal */}
      {zoomedPhoto && (
        <div
          onClick={() => setZoomedPhoto(null)}
          className="fixed inset-0 z-50 bg-black/90 backdrop-blur-sm p-4 flex flex-col items-center justify-center animate-in fade-in"
        >
          <button
            onClick={() => setZoomedPhoto(null)}
            className="absolute top-4 right-4 p-2 rounded-full bg-white/20 text-white hover:bg-white/30 transition"
          >
            <X className="w-6 h-6" />
          </button>
          <img
            src={zoomedPhoto}
            alt="Zoomed"
            className="max-w-full max-h-[88vh] object-contain rounded-xl shadow-2xl"
          />
          <p className="text-xs text-slate-400 mt-3">Click anywhere to close</p>
        </div>
      )}
    </div>
  );
};
