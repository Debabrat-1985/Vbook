import React, { useState, useEffect } from 'react';
import { Smartphone, Monitor } from 'lucide-react';

interface AndroidFrameProps {
  children: React.ReactNode;
}

export const AndroidFrame: React.FC<AndroidFrameProps> = ({ children }) => {
  const [isMobileDevice, setIsMobileDevice] = useState(false);
  const [forceMobileFrame, setForceMobileFrame] = useState(true);
  const [currentTime, setCurrentTime] = useState('10:00');

  useEffect(() => {
    const checkDevice = () => {
      const isMobile = window.innerWidth <= 768 || /Android|iPhone|iPad|iPod/i.test(navigator.userAgent);
      setIsMobileDevice(isMobile);
    };
    checkDevice();
    window.addEventListener('resize', checkDevice);

    const updateClock = () => {
      const now = new Date();
      const hours = String(now.getHours()).padStart(2, '0');
      const minutes = String(now.getMinutes()).padStart(2, '0');
      setCurrentTime(`${hours}:${minutes}`);
    };
    updateClock();
    const interval = setInterval(updateClock, 30000);

    return () => {
      window.removeEventListener('resize', checkDevice);
      clearInterval(interval);
    };
  }, []);

  // If on actual mobile device or user toggled full view on desktop
  if (isMobileDevice || !forceMobileFrame) {
    return (
      <div className="h-[100dvh] w-full bg-slate-950 text-slate-100 flex flex-col overflow-hidden fixed inset-0 selection:bg-indigo-500 selection:text-white">
        {/* Toggle bar for desktop preview */}
        {!isMobileDevice && (
          <div className="shrink-0 bg-slate-900 border-b border-slate-800 px-4 py-1.5 flex items-center justify-between text-xs text-slate-400 z-50">
            <span className="flex items-center gap-1.5 font-medium text-indigo-300">
              <Smartphone className="w-3.5 h-3.5" /> Full Screen Mode
            </span>
            <button
              onClick={() => setForceMobileFrame(true)}
              className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 transition"
            >
              <Smartphone className="w-3.5 h-3.5" /> Switch to Android Phone Frame
            </button>
          </div>
        )}
        <div className="flex-1 w-full max-w-2xl mx-auto flex flex-col overflow-hidden relative h-full min-h-0">
          {children}
        </div>
      </div>
    );
  }

  // Desktop Android Mockup view
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-indigo-950/60 p-4 md:p-8 flex flex-col items-center justify-center">
      {/* Top Frame Control Switcher */}
      <div className="mb-4 flex items-center gap-3 bg-slate-900/90 backdrop-blur border border-slate-800 px-4 py-2 rounded-full shadow-lg text-xs text-slate-300">
        <span className="font-semibold text-indigo-400 flex items-center gap-1.5">
          <Smartphone className="w-4 h-4" /> Android Material You Preview
        </span>
        <span className="text-slate-600">|</span>
        <button
          onClick={() => setForceMobileFrame(false)}
          className="flex items-center gap-1.5 text-slate-400 hover:text-white hover:underline transition"
        >
          <Monitor className="w-3.5 h-3.5" /> Expand to Full Screen
        </button>
      </div>

      {/* Android Device Shell (Pixel / Galaxy style) */}
      <div className="relative w-full max-w-[420px] h-[860px] max-h-[92vh] bg-black rounded-[48px] p-3 shadow-2xl shadow-indigo-950/50 border-[6px] border-slate-800 ring-1 ring-white/10 flex flex-col overflow-hidden">
        
        {/* Device Speaker Notch & Front Camera Punch Hole */}
        <div className="absolute top-4 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2 pointer-events-none">
          <div className="w-3 h-3 rounded-full bg-slate-900 border border-slate-800 shadow-inner" />
        </div>

        {/* Android Simulated Status Bar */}
        <div className="h-7 w-full bg-slate-950/90 backdrop-blur px-6 flex items-center justify-between text-[11px] font-semibold text-slate-300 z-40 select-none border-b border-white/5">
          <span>{currentTime}</span>
          <div className="flex items-center gap-2">
            <span className="text-[10px] tracking-wider text-emerald-400 font-bold">5G</span>
            {/* WiFi Icon SVG */}
            <svg className="w-3.5 h-3.5 text-slate-300" fill="currentColor" viewBox="0 0 24 24">
              <path d="M12 4C7.31 4 3.07 5.9 0 8.98L12 21 24 8.98A16.88 16.88 0 0 0 12 4zm0 3c3.7 0 7.07 1.48 9.57 3.89L12 19.33 2.43 10.89C4.93 8.48 8.3 7 12 7z" />
            </svg>
            {/* Battery Icon */}
            <div className="flex items-center gap-0.5">
              <div className="w-4 h-2.5 rounded-sm border border-slate-300 p-0.5 flex items-center">
                <div className="w-full h-full bg-emerald-400 rounded-2xs" />
              </div>
              <div className="w-0.5 h-1 bg-slate-300 rounded-r-2xs" />
            </div>
          </div>
        </div>

        {/* App Content Canvas inside Android */}
        <div className="flex-1 w-full overflow-hidden flex flex-col relative bg-slate-950 text-slate-100">
          {children}
        </div>

        {/* Android Gesture Navigation Pill */}
        <div className="h-5 w-full bg-slate-950 flex items-center justify-center z-40">
          <div className="w-32 h-1 bg-slate-600 rounded-full" />
        </div>
      </div>
    </div>
  );
};
