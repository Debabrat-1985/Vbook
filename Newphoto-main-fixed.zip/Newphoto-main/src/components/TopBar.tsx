import React from 'react';
import { ArrowLeft, Globe, WifiOff, Sparkles, LogIn, UserPlus } from 'lucide-react';
import { AppLanguage, UserProfile } from '../types';
import { getTranslation } from '../i18n/translations';

interface TopBarProps {
  title?: string;
  showBack?: boolean;
  onBack?: () => void;
  lang: AppLanguage;
  onLanguageChange: (lang: AppLanguage) => void;
  onOpenAuth: (mode?: 'login' | 'signup') => void;
  user: UserProfile | null;
  isOnline: boolean;
}

export const TopBar: React.FC<TopBarProps> = ({
  title,
  showBack,
  onBack,
  lang,
  onLanguageChange,
  onOpenAuth,
  user,
  isOnline,
}) => {
  const nextLang: Record<AppLanguage, AppLanguage> = {
    hinglish: 'hindi',
    hindi: 'english',
    english: 'hinglish',
  };

  const langLabel: Record<AppLanguage, string> = {
    hinglish: 'Hinglish',
    hindi: 'हिंदी',
    english: 'English',
  };

  return (
    <header className="sticky top-0 z-30 w-full bg-slate-950/90 backdrop-blur-md border-b border-slate-800/80 px-3 py-2 flex items-center justify-between gap-2 shadow-sm">
      {/* Left section: Back button or App Logo */}
      <div className="flex items-center gap-2 min-w-0">
        {showBack ? (
          <button
            onClick={onBack}
            className="p-2 -ml-1 rounded-full text-slate-300 hover:text-white hover:bg-slate-800 active:scale-95 transition"
            aria-label="Go Back"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
        ) : (
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-indigo-600 via-purple-600 to-pink-500 p-0.5 shadow-md shadow-indigo-500/20 flex items-center justify-center">
              <span className="text-white font-black text-sm">PB</span>
            </div>
          </div>
        )}

        <div className="min-w-0">
          <h1 className="text-base font-bold tracking-tight text-white truncate">
            {title || getTranslation(lang, 'appTitle')}
          </h1>
          {!title && (
            <p className="text-[10px] text-indigo-400 font-medium truncate flex items-center gap-1">
              <Sparkles className="w-2.5 h-2.5" /> Mobile Photobook Maker
            </p>
          )}
        </div>
      </div>

      {/* Right actions: Offline pill, Language toggle, User Avatar or Login/Signup */}
      <div className="flex items-center gap-1.5 shrink-0">
        {!isOnline && (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] font-semibold animate-pulse">
            <WifiOff className="w-3 h-3" /> Offline
          </span>
        )}

        {/* Language switch button */}
        <button
          onClick={() => onLanguageChange(nextLang[lang])}
          className="flex items-center gap-1 px-2 py-1 rounded-full bg-slate-900 border border-slate-700/80 text-[11px] font-medium text-slate-300 hover:text-white hover:border-indigo-500 transition active:scale-95"
          title="Switch Language"
        >
          <Globe className="w-3 h-3 text-indigo-400" />
          <span>{langLabel[lang]}</span>
        </button>

        {/* User Profile Avatar / Login trigger */}
        {user ? (
          <button
            onClick={() => onOpenAuth()}
            className="p-0.5 rounded-full ring-2 ring-indigo-500/40 hover:ring-indigo-400 transition active:scale-95"
            title={user.name}
          >
            <img
              src={user.avatarUrl}
              alt={user.name}
              className="w-7 h-7 rounded-full object-cover border border-slate-700"
            />
          </button>
        ) : (
          <div className="flex items-center gap-1">
            <button
              onClick={() => onOpenAuth('login')}
              className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-slate-900 border border-slate-700 text-slate-200 hover:text-white hover:border-indigo-500 text-[11px] font-semibold transition active:scale-95"
            >
              <LogIn className="w-3 h-3 text-indigo-400" />
              <span>Login</span>
            </button>
            <button
              onClick={() => onOpenAuth('signup')}
              className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-indigo-600 hover:bg-indigo-500 text-white text-[11px] font-semibold shadow-sm shadow-indigo-600/30 transition active:scale-95"
            >
              <UserPlus className="w-3 h-3" />
              <span>Sign Up</span>
            </button>
          </div>
        )}
      </div>
    </header>
  );
};
