import React from 'react';
import { Sparkles, BookOpen, ArrowRight } from 'lucide-react';
import { PhotoBook, AppLanguage, BookTheme } from '../types';
import { getTranslation } from '../i18n/translations';

interface TemplatesViewProps {
  lang: AppLanguage;
  onSelectTemplate: (template: Partial<PhotoBook>) => void;
}

const TEMPLATES: Array<{
  id: string;
  title: string;
  category: string;
  desc: string;
  theme: BookTheme;
  coverImage: string;
  pagesCount: number;
}> = [
  {
    id: 'tmpl-wedding',
    title: 'Shaadi & Sangeet Chronicles',
    category: 'Wedding & Engagement',
    desc: 'Golden royal borders, ritual pages (Haldi, Mehendi, Phere) and candid family memories.',
    theme: 'royal-gold',
    coverImage: 'https://images.unsplash.com/photo-1519741497674-611481863552?w=800&auto=format&fit=crop&q=80',
    pagesCount: 6,
  },
  {
    id: 'tmpl-travel',
    title: 'Himalayan Wanderlust',
    category: 'Travel & Trips',
    desc: 'Roadtrips, mountain snowscapes, campfires, and chai moments.',
    theme: 'vintage-leather',
    coverImage: 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=800&auto=format&fit=crop&q=80',
    pagesCount: 5,
  },
  {
    id: 'tmpl-baby',
    title: 'Little Miracle’s First Year',
    category: 'Baby & Kids',
    desc: 'Pastel dream layout for first smile, baby steps, and adorable milestones.',
    theme: 'blossom-pastel',
    coverImage: 'https://images.unsplash.com/photo-1555252333-9f8e92e65df9?w=800&auto=format&fit=crop&q=80',
    pagesCount: 6,
  },
  {
    id: 'tmpl-birthday',
    title: 'Birthday Bash & Besties',
    category: 'Birthday & Friendship',
    desc: 'Balloons, confetti, cake cutting, and crazy candid laughter.',
    theme: 'midnight-velvet',
    coverImage: 'https://images.unsplash.com/photo-1511285560929-80b456fea0bc?w=800&auto=format&fit=crop&q=80',
    pagesCount: 4,
  },
  {
    id: 'tmpl-beach',
    title: 'Goa Sun, Sand & Waves',
    category: 'Beach & Holiday',
    desc: 'Ocean teal vibes, golden sunsets, scooter rides, and chill vibes.',
    theme: 'ocean-teal',
    coverImage: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&auto=format&fit=crop&q=80',
    pagesCount: 5,
  }
];

export const TemplatesView: React.FC<TemplatesViewProps> = ({
  lang,
  onSelectTemplate,
}) => {
  return (
    <div className="p-4 flex flex-col gap-4 pb-28">
      <div>
        <h2 className="text-base font-bold text-white flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-yellow-400" />
          <span>{getTranslation(lang, 'allTemplates')}</span>
        </h2>
        <p className="text-xs text-slate-400 mt-0.5">
          Select a pre-designed layout to quickly populate your photos and customize.
        </p>
      </div>

      <div className="flex flex-col gap-3">
        {TEMPLATES.map((tmpl) => (
          <div
            key={tmpl.id}
            className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-lg hover:border-indigo-500/50 transition flex flex-col"
          >
            <div className="relative h-36 w-full">
              <img
                src={tmpl.coverImage}
                alt={tmpl.title}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent" />
              <span className="absolute top-2.5 left-2.5 px-2.5 py-0.5 rounded-full bg-black/60 backdrop-blur-xs text-white text-[10px] font-bold border border-white/10">
                {tmpl.category}
              </span>
              <span className="absolute bottom-2.5 right-2.5 px-2 py-0.5 rounded-md bg-indigo-600/90 text-white text-[10px] font-bold">
                {tmpl.pagesCount} Pages Pre-configured
              </span>
            </div>

            <div className="p-3.5 flex flex-col gap-2">
              <div>
                <h3 className="text-sm font-bold text-white">{tmpl.title}</h3>
                <p className="text-xs text-slate-400 mt-1 line-clamp-2">{tmpl.desc}</p>
              </div>

              <button
                onClick={() =>
                  onSelectTemplate({
                    title: tmpl.title,
                    subtitle: tmpl.desc,
                    theme: tmpl.theme,
                    coverImage: tmpl.coverImage,
                  })
                }
                className="w-full mt-1 py-2 px-3 rounded-xl bg-indigo-600/20 hover:bg-indigo-600 text-indigo-300 hover:text-white border border-indigo-500/30 text-xs font-semibold flex items-center justify-center gap-1.5 transition active:scale-95"
              >
                <span>{getTranslation(lang, 'useTemplate')}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
