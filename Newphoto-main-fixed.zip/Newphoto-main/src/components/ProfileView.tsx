import React from 'react';
import { 
  User, 
  Crown, 
  Gift, 
  Globe, 
  RotateCcw, 
  Share2, 
  LogIn, 
  UserPlus, 
  LogOut 
} from 'lucide-react';
import { UserProfile, AppLanguage, PhotoBook } from '../types';
import { USAGE_LIMITS } from '../utils/storage';

interface ProfileViewProps {
  user: UserProfile | null;
  books: PhotoBook[];
  lang: AppLanguage;
  onLanguageChange: (lang: AppLanguage) => void;
  onOpenAuth: (mode?: 'login' | 'signup') => void;
  onLogout: () => void;
  onUpgradePro: () => void;
  onClaimBonus: () => void;
  onResetData: () => void;
  onShareApp: () => void;
}

export const ProfileView: React.FC<ProfileViewProps> = ({
  user,
  books,
  lang,
  onLanguageChange,
  onOpenAuth,
  onLogout,
  onUpgradePro,
  onClaimBonus,
  onResetData,
  onShareApp,
}) => {
  const isPro = user?.tier === 'pro';
  const totalFreeBooks = USAGE_LIMITS.maxFreeBooks + (user?.bonusCredits || 0);

  return (
    <div className="p-4 flex flex-col gap-4 pb-28">
      {/* Profile Card */}
      {user ? (
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-4 shadow-xl flex items-center justify-between gap-3.5">
          <div className="flex items-center gap-3 min-w-0">
            <img
              src={user.avatarUrl}
              alt={user.name}
              className="w-14 h-14 rounded-full object-cover border-2 border-indigo-500 shadow-md shadow-indigo-500/20 shrink-0"
            />
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-white truncate">{user.name}</h2>
                {isPro ? (
                  <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] font-bold">
                    PRO VIP
                  </span>
                ) : (
                  <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] font-bold">
                    FREE TIER
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-400 truncate mt-0.5">{user.email}</p>
            </div>
          </div>
          <button
            onClick={onLogout}
            className="p-2 rounded-xl bg-slate-800 hover:bg-rose-950/40 text-slate-400 hover:text-rose-300 border border-slate-700 hover:border-rose-500/40 transition shrink-0"
            title="Log Out"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      ) : (
        /* Not logged in banner */
        <div className="bg-slate-900 border border-indigo-500/30 rounded-3xl p-5 shadow-xl flex flex-col gap-3 text-center items-center">
          <div className="w-14 h-14 rounded-full bg-indigo-600/20 text-indigo-400 flex items-center justify-center">
            <User className="w-7 h-7" />
          </div>
          <div>
            <h3 className="text-base font-bold text-white">Login ya Sign Up Karein</h3>
            <p className="text-xs text-slate-400 mt-1 max-w-[260px]">
              Apna account banayein taaki aap apne photobooks save aur access kar sakein.
            </p>
          </div>
          <div className="grid grid-cols-2 gap-2 w-full pt-1">
            <button
              onClick={() => onOpenAuth('signup')}
              className="py-2.5 px-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-md transition active:scale-95 flex items-center justify-center gap-1.5"
            >
              <UserPlus className="w-3.5 h-3.5" />
              <span>Sign Up Free</span>
            </button>
            <button
              onClick={() => onOpenAuth('login')}
              className="py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs border border-slate-700 transition active:scale-95 flex items-center justify-center gap-1.5"
            >
              <LogIn className="w-3.5 h-3.5" />
              <span>Log In</span>
            </button>
          </div>
        </div>
      )}

      {/* Plan & Limits Status Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-4 flex flex-col gap-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Crown className="w-5 h-5 text-amber-400" />
            <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider">
              {isPro ? 'Pro Membership Active' : 'Free Tier Usage & Limits'}
            </h3>
          </div>
          {!isPro && user && (
            <button
              onClick={onUpgradePro}
              className="text-xs text-indigo-400 font-bold hover:underline"
            >
              Unlock Pro
            </button>
          )}
        </div>

        {/* Meter summary */}
        <div className="grid grid-cols-2 gap-2 text-center">
          <div className="bg-slate-950 p-3 rounded-2xl border border-slate-800/80">
            <p className="text-[10px] text-slate-400 font-medium">Books Created</p>
            <p className="text-lg font-black text-white mt-0.5">
              {books.length} / {isPro ? '∞' : totalFreeBooks}
            </p>
          </div>
          <div className="bg-slate-950 p-3 rounded-2xl border border-slate-800/80">
            <p className="text-[10px] text-slate-400 font-medium">Max Pages/Book</p>
            <p className="text-lg font-black text-white mt-0.5">
              {isPro ? '50 Pages' : `${USAGE_LIMITS.maxPagesPerBook} Pages`}
            </p>
          </div>
        </div>

        {/* Earn Free Bonus Books section */}
        {!isPro && user && (
          <div className="p-3 rounded-2xl bg-gradient-to-r from-pink-950/40 via-purple-950/40 to-slate-950 border border-pink-500/30 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Gift className="w-5 h-5 text-pink-400 shrink-0" />
              <div>
                <p className="text-xs font-bold text-pink-200">Share & Earn Free Books</p>
                <p className="text-[10px] text-slate-400">Invite a friend to get +1 Free Book credit!</p>
              </div>
            </div>
            <button
              onClick={onClaimBonus}
              className="px-3 py-1.5 rounded-xl bg-pink-600 hover:bg-pink-500 text-white font-bold text-xs shadow-md shadow-pink-600/20 active:scale-95 transition shrink-0"
            >
              +1 Free
            </button>
          </div>
        )}
      </div>

      {/* Language Preferences */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-4 flex flex-col gap-3">
        <div className="flex items-center gap-2">
          <Globe className="w-5 h-5 text-indigo-400" />
          <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider">
            Language / Bhasha
          </h3>
        </div>

        <div className="grid grid-cols-3 gap-2">
          {[
            { id: 'hinglish' as AppLanguage, label: 'Hinglish', sub: 'Easy Mix' },
            { id: 'hindi' as AppLanguage, label: 'हिंदी', sub: 'Pure Hindi' },
            { id: 'english' as AppLanguage, label: 'English', sub: 'Global' },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => onLanguageChange(item.id)}
              className={`p-2.5 rounded-2xl border text-center transition ${
                lang === item.id
                  ? 'border-indigo-500 bg-indigo-600/20 text-white font-bold'
                  : 'border-slate-800 bg-slate-950 text-slate-400 hover:text-slate-200'
              }`}
            >
              <p className="text-xs">{item.label}</p>
              <p className="text-[10px] text-slate-500 font-normal mt-0.5">{item.sub}</p>
            </button>
          ))}
        </div>
      </div>

      {/* App Sharing & Reset Actions */}
      <div className="flex items-center gap-2">
        <button
          onClick={onShareApp}
          className="flex-1 py-3 rounded-2xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-200 text-xs font-semibold flex items-center justify-center gap-2 transition"
        >
          <Share2 className="w-4 h-4 text-indigo-400" />
          <span>Share App Link</span>
        </button>

        <button
          onClick={onResetData}
          className="py-3 px-4 rounded-2xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-400 hover:text-rose-400 text-xs font-semibold flex items-center justify-center gap-2 transition"
          title="Clear all books"
        >
          <RotateCcw className="w-4 h-4" />
          <span>Clear Data</span>
        </button>
      </div>
    </div>
  );
};
