import React, { useState, useRef } from 'react';
import { 
  Plus, 
  Trash2, 
  Image as ImageIcon, 
  Palette, 
  Eye, 
  Check, 
  Upload, 
  Sparkles, 
  Layout, 
  ChevronRight,
  ChevronLeft,
  Sliders,
  Type,
  Search,
  Maximize2,
  Volume2,
  VolumeX,
  BookOpen
} from 'lucide-react';
import { 
  PhotoBook, 
  BookPage, 
  BookPhoto, 
  PageLayoutType, 
  BookTheme, 
  PhotoFilter, 
  UserProfile, 
  AppLanguage,
  ThemeCategory
} from '../types';
import { THEME_CONFIGS, THEME_CATEGORIES } from '../utils/themePresets';
import { LAYOUT_CATALOG, LAYOUT_CATEGORIES } from '../utils/layoutCatalog';
import { PHOTO_FILTERS } from '../utils/filterStyles';
import { USAGE_LIMITS, canAddPageToBook } from '../utils/storage';
import { getTranslation } from '../i18n/translations';
import { soundEffects } from '../utils/audio';
import { PageLayoutRenderer } from './PageLayoutRenderer';

interface BookEditorProps {
  book: PhotoBook;
  user: UserProfile;
  lang: AppLanguage;
  onSave: (updated: PhotoBook) => void;
  onPreview: () => void;
  onReachLimit: (msg: string) => void;
}

const PRESET_SAMPLE_PHOTOS = [
  { url: 'https://images.unsplash.com/photo-1519741497674-611481863552?w=800&auto=format&fit=crop&q=80', label: 'Wedding Couple' },
  { url: 'https://images.unsplash.com/photo-1511285560929-80b456fea0bc?w=800&auto=format&fit=crop&q=80', label: 'Celebration' },
  { url: 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=800&auto=format&fit=crop&q=80', label: 'Snow Mountains' },
  { url: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&auto=format&fit=crop&q=80', label: 'Beach Sunset' },
  { url: 'https://images.unsplash.com/photo-1517824806704-9040b037703b?w=800&auto=format&fit=crop&q=80', label: 'Campfire' },
  { url: 'https://images.unsplash.com/photo-1522673607200-164d1b6ce486?w=800&auto=format&fit=crop&q=80', label: 'Friends' },
  { url: 'https://images.unsplash.com/photo-1555252333-9f8e92e65df9?w=800&auto=format&fit=crop&q=80', label: 'Baby Smile' },
  { url: 'https://images.unsplash.com/photo-1469371670807-013ccf25f16a?w=800&auto=format&fit=crop&q=80', label: 'Floral Decor' },
  { url: 'https://images.unsplash.com/photo-1529636798458-92182e662485?w=800&auto=format&fit=crop&q=80', label: 'The Toast' },
  { url: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=800&auto=format&fit=crop&q=80', label: 'Smiling Portrait' },
];

export const BookEditor: React.FC<BookEditorProps> = ({
  book,
  user,
  lang,
  onSave,
  onPreview,
  onReachLimit,
}) => {
  const [currentBook, setCurrentBook] = useState<PhotoBook>(book);
  const [activePageIndex, setActivePageIndex] = useState<number>(0);
  const [showPhotoPickerFor, setShowPhotoPickerFor] = useState<{ pageId: string; photoIdx: number } | null>(null);
  const [activeTab, setActiveTab] = useState<'pages' | 'theme' | 'details'>('pages');

  // Page Transition Animation State in BookEditor: 'palti' (3D flip), 'push-slide', 'cross-fade'
  const [pageAnimMode, setPageAnimMode] = useState<'palti' | 'push-slide' | 'cross-fade'>('palti');
  const [transitionDirection, setTransitionDirection] = useState<'next' | 'prev' | null>(null);
  const [isTransitioning, setIsTransitioning] = useState<boolean>(false);
  const [isSoundOn, setIsSoundOn] = useState<boolean>(true);
  const touchEditorStartX = useRef<number | null>(null);

  // Filter state for Layout Catalog
  const [layoutCategory, setLayoutCategory] = useState<string>('All (30)');
  // Filter state for 52 Themes
  const [themeCategory, setThemeCategory] = useState<string>('All (52)');
  const [themeSearch, setThemeSearch] = useState<string>('');

  const activePage: BookPage | undefined = currentBook.pages[activePageIndex];
  const { allowed: canAddPage, remaining: pagesRemaining } = canAddPageToBook(currentBook, user);
  const currentThemeConfig = THEME_CONFIGS[currentBook.theme] || THEME_CONFIGS['classic-linen'];

  // Smooth page turn navigation with native-feeling animations ('palti', 'push-slide', 'cross-fade')
  const navigateToPage = (newIndex: number) => {
    if (newIndex < 0 || newIndex >= currentBook.pages.length || newIndex === activePageIndex) {
      return;
    }
    const dir: 'next' | 'prev' = newIndex > activePageIndex ? 'next' : 'prev';
    setTransitionDirection(dir);
    setIsTransitioning(true);

    if (isSoundOn) {
      soundEffects.playPageTurn();
    }
    setActivePageIndex(newIndex);

    setTimeout(() => {
      setIsTransitioning(false);
      setTransitionDirection(null);
    }, 380);
  };

  // Helper to determine CSS animation class
  const getPageAnimClass = () => {
    if (!transitionDirection) return '';
    if (pageAnimMode === 'palti') {
      return transitionDirection === 'next' ? 'page-anim-palti-next' : 'page-anim-palti-prev';
    }
    if (pageAnimMode === 'push-slide') {
      return transitionDirection === 'next' ? 'page-anim-push-next' : 'page-anim-push-prev';
    }
    if (pageAnimMode === 'cross-fade') {
      return 'page-anim-cross-fade';
    }
    return '';
  };

  // Update book state & trigger autosave
  const updateBook = (newBook: PhotoBook) => {
    setCurrentBook(newBook);
    onSave(newBook);
  };

  // Add a new page
  const handleAddNewPage = () => {
    if (!canAddPage) {
      onReachLimit(getTranslation(lang, 'reachPageLimitDesc'));
      return;
    }

    const newPageNumber = currentBook.pages.length + 1;
    const newPage: BookPage = {
      id: `p-${Date.now()}`,
      pageNumber: newPageNumber,
      layout: 'single-full',
      title: `Page ${newPageNumber}`,
      subtitle: 'Memories worth holding forever',
      notes: '',
      photos: [
        {
          id: `ph-${Date.now()}`,
          url: PRESET_SAMPLE_PHOTOS[Math.floor(Math.random() * PRESET_SAMPLE_PHOTOS.length)].url,
          caption: 'Special moment',
          filter: 'normal',
        }
      ]
    };

    const updatedPages = [...currentBook.pages, newPage];
    const updatedBook = { ...currentBook, pages: updatedPages };
    updateBook(updatedBook);
    navigateToPage(updatedPages.length - 1);
  };

  // Delete current page
  const handleDeletePage = (index: number) => {
    if (currentBook.pages.length <= 1) return;
    const updatedPages = currentBook.pages.filter((_, i) => i !== index);
    const renumbered = updatedPages.map((p, i) => ({ ...p, pageNumber: i + 1 }));
    const updatedBook = { ...currentBook, pages: renumbered };
    updateBook(updatedBook);
    const targetIdx = Math.max(0, Math.min(index, renumbered.length - 1));
    setActivePageIndex(targetIdx);
  };

  // Change page layout
  const handleLayoutChange = (layout: PageLayoutType) => {
    if (!activePage) return;
    const meta = LAYOUT_CATALOG.find(l => l.id === layout);
    const requiredPhotosCount = meta ? meta.photoCount : 1;
    
    let photos = [...activePage.photos];
    while (photos.length < requiredPhotosCount) {
      const randomPreset = PRESET_SAMPLE_PHOTOS[photos.length % PRESET_SAMPLE_PHOTOS.length];
      photos.push({
        id: `ph-${Date.now()}-${photos.length}`,
        url: randomPreset.url,
        caption: '',
        filter: 'normal',
      });
    }

    const updatedPages = [...currentBook.pages];
    updatedPages[activePageIndex] = {
      ...activePage,
      layout,
      photos: photos.slice(0, Math.max(requiredPhotosCount, 1)),
    };
    updateBook({ ...currentBook, pages: updatedPages });
  };

  // Change photo URL or filter
  const handlePhotoUpdate = (photoIdx: number, updates: Partial<BookPhoto>) => {
    if (!activePage) return;
    const updatedPhotos = [...activePage.photos];
    if (updatedPhotos[photoIdx]) {
      updatedPhotos[photoIdx] = { ...updatedPhotos[photoIdx], ...updates };
    }
    const updatedPages = [...currentBook.pages];
    updatedPages[activePageIndex] = { ...activePage, photos: updatedPhotos };
    updateBook({ ...currentBook, pages: updatedPages });
  };

  // Handle local image upload via file input
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>, photoIdx: number) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const result = event.target?.result as string;
      if (result) {
        handlePhotoUpdate(photoIdx, { url: result });
        setShowPhotoPickerFor(null);
      }
    };
    reader.readAsDataURL(file);
  };

  // Filtered layouts
  const filteredLayouts = LAYOUT_CATALOG.filter((lay) => {
    if (layoutCategory.startsWith('All')) return true;
    if (layoutCategory.startsWith('Round & Shapes')) return lay.category === 'Round & Shapes';
    if (layoutCategory.startsWith('Classic')) return lay.category === 'Classic';
    if (layoutCategory.startsWith('Grids & Mosaic')) return lay.category === 'Grids & Mosaic';
    if (layoutCategory.startsWith('Artistic & Vintage')) return lay.category === 'Artistic & Vintage';
    return lay.category === layoutCategory;
  });

  // Filtered 52 Themes
  const allThemesList = Object.values(THEME_CONFIGS);
  const filteredThemes = allThemesList.filter((thm) => {
    const matchesCategory = themeCategory === 'All (52)' || thm.category === themeCategory;
    const matchesSearch = 
      !themeSearch.trim() ||
      thm.name.toLowerCase().includes(themeSearch.toLowerCase()) ||
      thm.nameHinglish.toLowerCase().includes(themeSearch.toLowerCase()) ||
      thm.category.toLowerCase().includes(themeSearch.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="flex-1 flex flex-col justify-between overflow-hidden bg-slate-950 text-slate-100 h-full">
      {/* 1. TOP EDITOR SUBNAV (PINNED / STICKY) */}
      <div className="shrink-0 bg-slate-900/95 backdrop-blur-md border-b border-slate-800 px-3 py-2 flex items-center justify-between shadow-sm z-20">
        <div className="flex items-center gap-1 bg-slate-800/90 p-0.5 rounded-xl text-xs font-semibold">
          <button
            onClick={() => setActiveTab('pages')}
            className={`px-3 py-1.5 rounded-lg transition ${
              activeTab === 'pages' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-300 hover:text-white'
            }`}
          >
            Pages ({currentBook.pages.length}/{USAGE_LIMITS.maxPagesPerBook})
          </button>
          <button
            onClick={() => setActiveTab('theme')}
            className={`px-3 py-1.5 rounded-lg transition ${
              activeTab === 'theme' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-300 hover:text-white'
            }`}
          >
            Theme (52)
          </button>
          <button
            onClick={() => setActiveTab('details')}
            className={`px-3 py-1.5 rounded-lg transition ${
              activeTab === 'details' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-300 hover:text-white'
            }`}
          >
            Details
          </button>
        </div>

        {/* Preview Flipbook Button */}
        <button
          onClick={onPreview}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-pink-600 to-indigo-600 text-white text-xs font-bold shadow-md shadow-pink-600/20 active:scale-95 transition"
        >
          <Eye className="w-3.5 h-3.5" />
          <span>Flipbook</span>
        </button>
      </div>

      {/* 2. SCROLLABLE MIDDLE CONTENT AREA */}
      <div className="flex-1 overflow-y-auto overscroll-contain pb-6">
        
        {/* TAB 1: PAGES MANAGER & PAGE EDITOR */}
        {activeTab === 'pages' && (
          <div className="p-3 flex flex-col gap-4">
            
            {/* Horizontal Pages Carousel Thumbnails */}
            <div className="bg-slate-900/70 border border-slate-800/80 rounded-2xl p-3">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                  <Layout className="w-3.5 h-3.5 text-indigo-400" />
                  <span>Album Pages</span>
                </span>
                <span className="text-[11px] text-slate-400">
                  {pagesRemaining} free pages remaining
                </span>
              </div>

              <div className="flex items-center gap-2 overflow-x-auto pb-1.5 scrollbar-none">
                {currentBook.pages.map((p, idx) => (
                  <button
                    key={p.id}
                    onClick={() => navigateToPage(idx)}
                    className={`shrink-0 w-16 h-22 rounded-xl p-1.5 flex flex-col justify-between border-2 transition text-left relative ${
                      idx === activePageIndex
                        ? 'border-indigo-500 bg-indigo-950/40 shadow-md ring-2 ring-indigo-500/20'
                        : 'border-slate-800 bg-slate-900 opacity-70 hover:opacity-100'
                    }`}
                  >
                    <span className="text-[9px] font-bold text-slate-400">#{idx + 1}</span>
                    {p.photos[0] ? (
                      <img
                        src={p.photos[0].url}
                        alt="Thumb"
                        className="w-full h-10 object-contain bg-slate-950/80 rounded-md"
                      />
                    ) : (
                      <div className="w-full h-10 bg-slate-800 rounded-md flex items-center justify-center text-[9px] text-slate-500">
                        Txt
                      </div>
                    )}
                    <span className="text-[8px] truncate text-slate-300 font-medium">
                      {p.layout}
                    </span>
                  </button>
                ))}

                {/* Add New Page Button */}
                <button
                  onClick={handleAddNewPage}
                  className="shrink-0 w-16 h-22 rounded-xl border-2 border-dashed border-slate-700 bg-slate-900/60 hover:border-indigo-500 flex flex-col items-center justify-center gap-1 text-slate-400 hover:text-indigo-300 transition active:scale-95"
                  title="Add New Page"
                >
                  <Plus className="w-5 h-5 text-indigo-400" />
                  <span className="text-[9px] font-semibold">Add</span>
                </button>
              </div>
            </div>

            {/* LIVE PAGE PREVIEW (TASTE OF THE FINAL BOOK) WITH ANIMATION & CONTROLS */}
            {activePage && (
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3 shadow-lg flex flex-col gap-2.5">
                {/* Header with Title, Animation Mode Selector, Sound and Fullscreen */}
                <div className="flex flex-wrap items-center justify-between gap-2 text-xs border-b border-slate-800/80 pb-2">
                  <span className="font-bold text-slate-200 flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-yellow-400" />
                    <span>Live Page Preview</span>
                  </span>

                  {/* Transition Mode Selector Pills */}
                  <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800">
                    <button
                      onClick={() => setPageAnimMode('palti')}
                      className={`px-2 py-0.5 rounded-lg text-[10px] font-bold transition flex items-center gap-1 ${
                        pageAnimMode === 'palti'
                          ? 'bg-indigo-600 text-white shadow-xs'
                          : 'text-slate-400 hover:text-white'
                      }`}
                      title="Book Palti / 3D Page Turn Effect"
                    >
                      <span>📖 Palti</span>
                    </button>
                    <button
                      onClick={() => setPageAnimMode('push-slide')}
                      className={`px-2 py-0.5 rounded-lg text-[10px] font-bold transition flex items-center gap-1 ${
                        pageAnimMode === 'push-slide'
                          ? 'bg-indigo-600 text-white shadow-xs'
                          : 'text-slate-400 hover:text-white'
                      }`}
                      title="Push-Slide Transition Effect"
                    >
                      <span>↔️ Slide</span>
                    </button>
                    <button
                      onClick={() => setPageAnimMode('cross-fade')}
                      className={`px-2 py-0.5 rounded-lg text-[10px] font-bold transition flex items-center gap-1 ${
                        pageAnimMode === 'cross-fade'
                          ? 'bg-indigo-600 text-white shadow-xs'
                          : 'text-slate-400 hover:text-white'
                      }`}
                      title="Cross-Fade Dissolve Effect"
                    >
                      <span>🔀 Fade</span>
                    </button>

                    <button
                      onClick={() => setIsSoundOn(!isSoundOn)}
                      className={`p-1 rounded-lg transition ml-0.5 ${
                        isSoundOn ? 'text-indigo-400 hover:text-indigo-300' : 'text-slate-600'
                      }`}
                      title={isSoundOn ? 'Page Turn Sound On' : 'Page Turn Sound Off'}
                    >
                      {isSoundOn ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5" />}
                    </button>
                  </div>

                  <button
                    onClick={onPreview}
                    className="text-[11px] text-indigo-400 hover:text-indigo-300 hover:underline flex items-center gap-1 ml-auto"
                  >
                    <Maximize2 className="w-3 h-3" /> Full 3D
                  </button>
                </div>
                
                {/* 3D Book Page Canvas with Page Turn Effect & Gesture Support */}
                <div 
                  className="relative w-full aspect-[1/1.25] max-h-[380px] rounded-xl overflow-hidden shadow-2xl border border-slate-700/60 bg-slate-950 flex flex-col group perspective-1500 select-none"
                  onTouchStart={(e) => {
                    touchEditorStartX.current = e.touches[0].clientX;
                  }}
                  onTouchEnd={(e) => {
                    if (touchEditorStartX.current === null) return;
                    const diff = touchEditorStartX.current - e.changedTouches[0].clientX;
                    if (Math.abs(diff) > 36) {
                      if (diff > 0) {
                        navigateToPage(activePageIndex + 1);
                      } else {
                        navigateToPage(activePageIndex - 1);
                      }
                    }
                    touchEditorStartX.current = null;
                  }}
                >
                  {/* Subtle Book Spine crease on left edge */}
                  <div className="absolute left-0 top-0 bottom-0 w-4 bg-gradient-to-r from-black/30 via-black/10 to-transparent pointer-events-none z-20" />
                  {/* Right edge shadow */}
                  <div className="absolute right-0 top-0 bottom-0 w-2.5 bg-gradient-to-l from-black/15 to-transparent pointer-events-none z-20" />

                  {/* Paper sheen sweep when page is turned (palti) */}
                  {isTransitioning && pageAnimMode === 'palti' && (
                    <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent pointer-events-none z-30 paper-sheen-sweep" />
                  )}

                  {/* Animated Page Renderer Container */}
                  <div
                    key={`editor-page-${activePage.id}`}
                    className={`w-full h-full flex flex-col ${getPageAnimClass()}`}
                  >
                    <PageLayoutRenderer
                      page={activePage}
                      themeConfig={currentThemeConfig}
                      isCover={activePage.layout === 'cover'}
                      isBackCover={activePage.layout === 'back-cover'}
                      bookTitle={currentBook.title}
                      authorName={currentBook.authorName}
                    />
                  </div>

                  {/* Overlay Prev / Next Buttons directly on preview */}
                  {activePageIndex > 0 && (
                    <button
                      onClick={() => navigateToPage(activePageIndex - 1)}
                      className="absolute left-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-slate-950/70 hover:bg-indigo-600 text-white flex items-center justify-center backdrop-blur-xs border border-white/20 shadow-lg opacity-80 hover:opacity-100 transition-all z-30 active:scale-95"
                      title="Previous Page (Palti backward)"
                    >
                      <ChevronLeft className="w-5 h-5" />
                    </button>
                  )}

                  {activePageIndex < currentBook.pages.length - 1 && (
                    <button
                      onClick={() => navigateToPage(activePageIndex + 1)}
                      className="absolute right-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-slate-950/70 hover:bg-indigo-600 text-white flex items-center justify-center backdrop-blur-xs border border-white/20 shadow-lg opacity-80 hover:opacity-100 transition-all z-30 active:scale-95"
                      title="Next Page (Palti forward)"
                    >
                      <ChevronRight className="w-5 h-5" />
                    </button>
                  )}
                </div>

                {/* Quick Interactive Page Navigation Bar right under Preview */}
                <div className="flex items-center justify-between bg-slate-950/70 border border-slate-800 px-3 py-1.5 rounded-xl text-xs">
                  <button
                    onClick={() => navigateToPage(activePageIndex - 1)}
                    disabled={activePageIndex === 0 || isTransitioning}
                    className={`flex items-center gap-1 px-2.5 py-1 rounded-lg font-semibold transition ${
                      activePageIndex === 0
                        ? 'text-slate-600 cursor-not-allowed'
                        : 'bg-slate-800 text-slate-200 hover:bg-slate-700 active:scale-95'
                    }`}
                  >
                    <ChevronLeft className="w-3.5 h-3.5" />
                    <span>Prev</span>
                  </button>

                  <div className="flex items-center gap-1.5">
                    <span className="font-bold text-slate-300 text-[11px]">
                      Page {activePageIndex + 1} of {currentBook.pages.length}
                    </span>
                    <span className="text-[10px] text-indigo-400 font-medium bg-indigo-950/60 border border-indigo-500/30 px-2 py-0.5 rounded-full">
                      {pageAnimMode === 'palti' ? '📖 Palti' : pageAnimMode === 'push-slide' ? '↔️ Push Slide' : '🔀 Fade'}
                    </span>
                  </div>

                  <button
                    onClick={() => navigateToPage(activePageIndex + 1)}
                    disabled={activePageIndex === currentBook.pages.length - 1 || isTransitioning}
                    className={`flex items-center gap-1 px-2.5 py-1 rounded-lg font-semibold transition ${
                      activePageIndex === currentBook.pages.length - 1
                        ? 'text-slate-600 cursor-not-allowed'
                        : 'bg-indigo-600 text-white hover:bg-indigo-500 shadow-sm shadow-indigo-600/30 active:scale-95'
                    }`}
                  >
                    <span>Next</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            )}

            {/* ACTIVE PAGE DETAILED EDIT FORM */}
            {activePage && (
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-xl flex flex-col gap-4">
                
                {/* Header of Active Page with Delete option */}
                <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded-lg bg-indigo-600/30 text-indigo-300 text-xs font-bold border border-indigo-500/30">
                      Page #{activePageIndex + 1}
                    </span>
                    <span className="text-xs font-semibold text-slate-300 capitalize">
                      {LAYOUT_CATALOG.find(l => l.id === activePage.layout)?.name || activePage.layout}
                    </span>
                  </div>

                  {currentBook.pages.length > 1 && (
                    <button
                      onClick={() => handleDeletePage(activePageIndex)}
                      className="p-1.5 rounded-lg text-rose-400 hover:bg-rose-500/10 transition"
                      title="Delete Page"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>

                {/* 30 PAGE LAYOUTS WITH UNIQUE SHAPES & ROUND FRAMES */}
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <label className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
                      <Layout className="w-3.5 h-3.5 text-indigo-400" />
                      <span>Choose Page Layout (30 Unique Designs)</span>
                    </label>
                    <span className="text-[10px] text-emerald-300 font-semibold bg-emerald-950/60 border border-emerald-500/30 px-2 py-0.5 rounded-full">
                      ✓ Auto Fit & Adjust
                    </span>
                  </div>

                  {/* Category filter pills for layouts */}
                  <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none pb-2 mb-2">
                    {LAYOUT_CATEGORIES.map((cat) => (
                      <button
                        key={cat}
                        onClick={() => setLayoutCategory(cat)}
                        className={`shrink-0 px-2.5 py-1 rounded-full text-[11px] font-medium transition active:scale-95 ${
                          layoutCategory === cat
                            ? 'bg-indigo-600 text-white font-bold shadow-sm'
                            : 'bg-slate-800 text-slate-400 hover:text-slate-200'
                        }`}
                      >
                        {cat}
                      </button>
                    ))}
                  </div>

                  {/* Layout grid cards with overflow scroll */}
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 max-h-80 overflow-y-auto pr-1 overscroll-contain">
                    {filteredLayouts.map((lay) => {
                      const isSelected = activePage.layout === lay.id;
                      return (
                        <button
                          key={lay.id}
                          onClick={() => handleLayoutChange(lay.id)}
                          className={`p-2.5 rounded-xl border text-left flex flex-col justify-between gap-1 transition relative ${
                            isSelected
                              ? 'border-indigo-500 bg-indigo-950/60 ring-2 ring-indigo-500/30 text-white shadow-md'
                              : 'border-slate-800 bg-slate-950 text-slate-300 hover:border-slate-700 hover:text-white'
                          }`}
                        >
                          <div className="flex items-center justify-between w-full">
                            <span className="text-xs font-bold">{lay.badge}</span>
                            {isSelected && (
                              <span className="w-4 h-4 rounded-full bg-indigo-500 text-white flex items-center justify-center text-[10px]">
                                ✓
                              </span>
                            )}
                          </div>
                          <div>
                            <p className="text-xs font-bold leading-tight truncate">{lay.name}</p>
                            <p className="text-[10px] text-slate-400 truncate">{lay.nameHinglish}</p>
                          </div>
                          <div className="flex items-center justify-between w-full mt-0.5">
                            <span className="text-[9px] px-1.5 py-0.5 rounded bg-slate-800/80 text-indigo-300 inline-block">
                              {lay.photoCount === 0 ? 'Text only' : `${lay.photoCount} Photo${lay.photoCount > 1 ? 's' : ''}`}
                            </span>
                            <span className="text-[8px] text-slate-500 font-mono">100% Fit</span>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Page Title & Notes Inputs */}
                <div className="flex flex-col gap-2.5 pt-2 border-t border-slate-800/80">
                  <div>
                    <label className="text-[11px] font-semibold text-slate-400 mb-1 block">
                      Page Heading / Title
                    </label>
                    <input
                      type="text"
                      value={activePage.title || ''}
                      onChange={(e) => {
                        const updatedPages = [...currentBook.pages];
                        updatedPages[activePageIndex] = { ...activePage, title: e.target.value };
                        updateBook({ ...currentBook, pages: updatedPages });
                      }}
                      placeholder="e.g., Sangeet Night, Beach Sunrise..."
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-indigo-500"
                    />
                  </div>

                  <div>
                    <label className="text-[11px] font-semibold text-slate-400 mb-1 block">
                      Story / Caption / Journal Note
                    </label>
                    <textarea
                      rows={2}
                      value={activePage.notes || ''}
                      onChange={(e) => {
                        const updatedPages = [...currentBook.pages];
                        updatedPages[activePageIndex] = { ...activePage, notes: e.target.value };
                        updateBook({ ...currentBook, pages: updatedPages });
                      }}
                      placeholder="Write the story behind these photos..."
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-indigo-500 resize-none"
                    />
                  </div>
                </div>

                {/* PHOTOS, FIT CONTROLS, AND 28 PHOTO FILTERS (SCROLLABLE) */}
                {activePage.photos.length > 0 && (
                  <div className="pt-2 border-t border-slate-800/80 flex flex-col gap-2.5">
                    <label className="text-xs font-bold text-slate-200 flex items-center justify-between">
                      <span className="flex items-center gap-1.5">
                        <ImageIcon className="w-3.5 h-3.5 text-indigo-400" />
                        <span>Photos & Fitting on this page ({activePage.photos.length})</span>
                      </span>
                      <span className="text-[10px] text-slate-400">Warm, Cool, Vintage filters 👉</span>
                    </label>

                    <div className="flex flex-col gap-3">
                      {activePage.photos.map((photo, pIdx) => (
                        <div
                          key={photo.id}
                          className="bg-slate-950 p-3 rounded-2xl border border-slate-800 flex flex-col gap-2.5 shadow-md"
                        >
                          <div className="flex items-center gap-3">
                            <img
                              src={photo.url}
                              alt="Slot"
                              className="w-16 h-16 rounded-xl object-contain bg-slate-900 shrink-0 border border-slate-700 p-0.5"
                            />
                            <div className="flex-1 min-w-0 flex flex-col gap-1.5">
                              <input
                                type="text"
                                value={photo.caption || ''}
                                onChange={(e) => handlePhotoUpdate(pIdx, { caption: e.target.value })}
                                placeholder="Add photo caption..."
                                className="w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-indigo-500"
                              />
                              <div className="flex items-center gap-2">
                                <button
                                  onClick={() => setShowPhotoPickerFor({ pageId: activePage.id, photoIdx: pIdx })}
                                  className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-indigo-300 text-xs font-semibold transition active:scale-95 flex items-center gap-1"
                                >
                                  <Upload className="w-3 h-3" />
                                  <span>Change Photo</span>
                                </button>
                                
                                {/* Photo Fit Mode Toggle */}
                                <button
                                  onClick={() =>
                                    handlePhotoUpdate(pIdx, {
                                      fitMode: photo.fitMode === 'cover' ? 'contain' : 'cover',
                                    })
                                  }
                                  className={`px-2 py-1 rounded-lg text-[10px] font-semibold border transition active:scale-95 ${
                                    photo.fitMode === 'cover'
                                      ? 'bg-amber-950/40 text-amber-300 border-amber-500/40'
                                      : 'bg-emerald-950/40 text-emerald-300 border-emerald-500/40'
                                  }`}
                                  title="Toggle between Contain (100% full photo visible) and Cover (Fill frame)"
                                >
                                  {photo.fitMode === 'cover' ? 'Fit: Fill Frame' : 'Fit: Full (No Crop)'}
                                </button>
                              </div>
                            </div>
                          </div>

                          {/* 28 FILTERS: SCROLLABLE HORIZONTAL STRIP (WARM, COOL, VINTAGE AT TOP) */}
                          <div className="flex flex-col gap-1 pt-1.5 border-t border-slate-900">
                            <div className="flex items-center justify-between text-[10px]">
                              <span className="text-slate-400 font-medium">
                                Photo Filter / Tone (28 Options):
                              </span>
                              <span className="text-indigo-400 font-medium">
                                Active: {PHOTO_FILTERS.find((f) => f.id === photo.filter)?.label || 'Original'}
                              </span>
                            </div>
                            <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none py-1 px-0.5">
                              {PHOTO_FILTERS.map((f) => (
                                <button
                                  key={f.id}
                                  onClick={() => handlePhotoUpdate(pIdx, { filter: f.id })}
                                  className={`shrink-0 flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-medium transition active:scale-95 ${
                                    photo.filter === f.id
                                      ? 'bg-indigo-600 text-white font-bold shadow-md shadow-indigo-600/30 ring-1 ring-white/30'
                                      : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
                                  }`}
                                >
                                  <span
                                    className="w-2.5 h-2.5 rounded-full border border-white/20 shrink-0"
                                    style={{ backgroundColor: f.color }}
                                  />
                                  <span>{f.label}</span>
                                </button>
                              ))}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {/* TAB 2: 50+ UNIQUE NEXT-LEVEL THEMES */}
        {activeTab === 'theme' && (
          <div className="p-3 flex flex-col gap-3">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                  <Palette className="w-4 h-4 text-indigo-400" />
                  <span>Choose Photobook Theme (52 Designs)</span>
                </h3>
                <p className="text-xs text-slate-400">
                  Royal, Minimal, Romance, Nature, Dark & Festive Palettes
                </p>
              </div>
            </div>

            {/* Search Input for Themes */}
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={themeSearch}
                onChange={(e) => setThemeSearch(e.target.value)}
                placeholder="Search 52 themes (e.g. Royal, Gold, Pink, Noir, Vintage)..."
                className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-9 pr-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
              />
            </div>

            {/* Category Filter Pills for Themes */}
            <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none pb-1">
              {['All (52)', ...THEME_CATEGORIES].map((cat) => (
                <button
                  key={cat}
                  onClick={() => setThemeCategory(cat)}
                  className={`shrink-0 px-2.5 py-1 rounded-full text-[11px] font-medium transition active:scale-95 ${
                    themeCategory === cat
                      ? 'bg-indigo-600 text-white font-bold shadow-sm'
                      : 'bg-slate-800 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            {/* 52 Themes Scrollable Grid */}
            <div className="grid grid-cols-2 gap-3 max-h-[66vh] overflow-y-auto pr-1 pb-16 overscroll-contain">
              {filteredThemes.map((thm) => {
                const isSelected = currentBook.theme === thm.id;
                return (
                  <button
                    key={thm.id}
                    onClick={() => updateBook({ ...currentBook, theme: thm.id })}
                    className={`p-3.5 rounded-2xl border-2 text-left flex flex-col justify-between h-36 transition relative overflow-hidden active:scale-98 shadow-md ${
                      isSelected
                        ? 'border-indigo-500 ring-2 ring-indigo-500/30 shadow-indigo-950/80'
                        : 'border-slate-800 hover:border-slate-700'
                    }`}
                    style={{ backgroundColor: thm.spineColor }}
                  >
                    {/* Color indicator and active checkmark */}
                    <div className="flex items-center justify-between w-full">
                      <div className="flex items-center gap-1.5">
                        <span
                          className="w-4 h-4 rounded-full border border-white/30 shadow-xs"
                          style={{ backgroundColor: thm.accentColor }}
                        />
                        <span className="text-[9px] px-1.5 py-0.5 rounded bg-black/40 text-slate-300 font-mono">
                          {thm.category.split('&')[0]}
                        </span>
                      </div>
                      {isSelected && (
                        <span className="w-5 h-5 rounded-full bg-indigo-500 text-white flex items-center justify-center text-xs shadow-md">
                          <Check className="w-3 h-3" />
                        </span>
                      )}
                    </div>

                    <div>
                      <h4 className="font-bold text-xs sm:text-sm text-white leading-tight">
                        {thm.name}
                      </h4>
                      <p className="text-[10px] text-slate-300 opacity-80 mt-0.5 truncate">
                        {thm.nameHinglish}
                      </p>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* TAB 3: BOOK DETAILS */}
        {activeTab === 'details' && (
          <div className="p-3 flex flex-col gap-4">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex flex-col gap-3">
              <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-1">
                Photobook Title & Author
              </h3>

              <div>
                <label className="text-[11px] font-semibold text-slate-400 mb-1 block">
                  Album Title
                </label>
                <input
                  type="text"
                  value={currentBook.title}
                  onChange={(e) => updateBook({ ...currentBook, title: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm font-semibold text-white focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="text-[11px] font-semibold text-slate-400 mb-1 block">
                  Subtitle / Dedication
                </label>
                <input
                  type="text"
                  value={currentBook.subtitle}
                  onChange={(e) => updateBook({ ...currentBook, subtitle: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="text-[11px] font-semibold text-slate-400 mb-1 block">
                  Author Name
                </label>
                <input
                  type="text"
                  value={currentBook.authorName}
                  onChange={(e) => updateBook({ ...currentBook, authorName: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
                />
              </div>
            </div>
          </div>
        )}
      </div>

      {/* 3. PINNED BOTTOM ACTION BAR */}
      <div className="shrink-0 bg-slate-900/95 backdrop-blur-md border-t border-slate-800 px-3 py-2.5 flex items-center justify-between text-xs z-20">
        <span className="text-[11px] text-slate-400 flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span>Autosaved</span>
        </span>
        <button
          onClick={onPreview}
          className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-md shadow-indigo-600/30 transition active:scale-95"
        >
          <Eye className="w-3.5 h-3.5" />
          <span>Flipbook Preview</span>
        </button>
      </div>

      {/* PHOTO PICKER BOTTOM SHEET DIALOG */}
      {showPhotoPickerFor && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex flex-col justify-end animate-in fade-in">
          <div className="bg-slate-900 border-t border-slate-800 rounded-t-3xl p-4 max-h-[85vh] overflow-y-auto">
            <div className="w-12 h-1 bg-slate-700 rounded-full mx-auto mb-3" />
            
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-bold text-white">Select Photo</h3>
              <button
                onClick={() => setShowPhotoPickerFor(null)}
                className="text-xs text-slate-400 hover:text-white"
              >
                Cancel
              </button>
            </div>

            {/* Local Upload option */}
            <label className="flex items-center justify-center gap-2 w-full py-3 px-4 rounded-xl border-2 border-dashed border-indigo-500/50 bg-indigo-950/20 text-indigo-300 font-semibold text-xs cursor-pointer hover:bg-indigo-950/40 transition mb-4">
              <Upload className="w-4 h-4" />
              <span>{getTranslation(lang, 'uploadLocalPhoto')}</span>
              <input
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => handleFileUpload(e, showPhotoPickerFor.photoIdx)}
              />
            </label>

            {/* Curated Presets */}
            <p className="text-[11px] font-semibold text-slate-400 mb-2">
              Or pick from high-res sample photos:
            </p>
            <div className="grid grid-cols-2 gap-2">
              {PRESET_SAMPLE_PHOTOS.map((p, idx) => (
                <div
                  key={idx}
                  onClick={() => {
                    handlePhotoUpdate(showPhotoPickerFor.photoIdx, { url: p.url });
                    setShowPhotoPickerFor(null);
                  }}
                  className="rounded-xl overflow-hidden border border-slate-800 cursor-pointer group relative"
                >
                  <img
                    src={p.url}
                    alt={p.label}
                    className="w-full h-24 object-cover group-hover:scale-105 transition"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex items-end p-2">
                    <span className="text-[10px] text-white font-medium">{p.label}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
