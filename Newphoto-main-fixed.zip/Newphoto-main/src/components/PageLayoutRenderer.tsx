import React from 'react';
import { BookPage, BookThemeConfig, BookPhoto } from '../types';
import { getPhotoFilterStyle } from '../utils/filterStyles';
import { ZoomIn, BookOpen, Heart, Sparkles, Feather, Star } from 'lucide-react';

interface PageLayoutRendererProps {
  page: BookPage;
  themeConfig: BookThemeConfig;
  onPhotoClick?: (url: string) => void;
  isCover?: boolean;
  isBackCover?: boolean;
  bookTitle?: string;
  authorName?: string;
}

export const PageLayoutRenderer: React.FC<PageLayoutRendererProps> = ({
  page,
  themeConfig,
  onPhotoClick,
  isCover = false,
  isBackCover = false,
  bookTitle,
  authorName,
}) => {
  const photos = page.photos || [];

  const renderSinglePhotoFrame = (
    photo: BookPhoto | undefined,
    idx: number,
    options?: {
      shape?: 'rect' | 'circle' | 'arch' | 'oval' | 'polaroid' | 'stamp' | 'diamond' | 'heart' | 'star' | 'scallop' | 'blob' | 'hex';
      className?: string;
      showCaption?: boolean;
    }
  ) => {
    if (!photo || !photo.url) {
      return (
        <div className={`bg-slate-200/50 rounded-xl flex items-center justify-center text-xs text-slate-400 p-4 border border-dashed border-slate-300 ${options?.className || 'w-full h-36'}`}>
          <span>Photo slot #{idx + 1}</span>
        </div>
      );
    }

    const shape = options?.shape || 'rect';
    const filterCss = getPhotoFilterStyle(photo.filter);
    const fitClass = photo.fitMode === 'cover' ? 'w-full h-full object-cover' : 'relative max-w-full max-h-full object-contain';

    // 1. CIRCLE SHAPE
    if (shape === 'circle') {
      return (
        <div
          onClick={() => onPhotoClick?.(photo.url)}
          className={`relative rounded-full overflow-hidden shadow-xl ring-4 ring-white/90 p-1 flex items-center justify-center bg-slate-900/10 cursor-pointer group transition-transform active:scale-98 ${options?.className || 'w-48 h-48'}`}
        >
          {/* Ambient soft glow backdrop ensures no harsh black edges while keeping photo fully fitted */}
          <img
            src={photo.url}
            alt=""
            className="absolute inset-0 w-full h-full object-cover blur-md opacity-35 scale-125 pointer-events-none"
          />
          <img
            src={photo.url}
            alt={photo.caption || 'Photo'}
            className={`${fitClass} rounded-full shadow-sm group-hover:scale-103 transition-transform duration-300`}
            style={{ filter: filterCss }}
          />
          <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 flex items-center justify-center rounded-full transition">
            <ZoomIn className="w-5 h-5 text-white" />
          </div>
        </div>
      );
    }

    // 2. ARCH PORTAL
    if (shape === 'arch') {
      return (
        <div
          onClick={() => onPhotoClick?.(photo.url)}
          className={`relative rounded-t-[100px] rounded-b-2xl overflow-hidden shadow-xl ring-2 ring-black/15 p-1.5 flex items-center justify-center bg-slate-900/10 cursor-pointer group ${options?.className || 'w-full flex-1 max-h-[340px]'}`}
        >
          <img
            src={photo.url}
            alt=""
            className="absolute inset-0 w-full h-full object-cover blur-md opacity-30 scale-110 pointer-events-none"
          />
          <img
            src={photo.url}
            alt={photo.caption || 'Photo'}
            className={`${fitClass} rounded-t-[94px] rounded-b-xl drop-shadow-md group-hover:scale-102 transition-transform duration-300`}
            style={{ filter: filterCss }}
          />
          <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 flex items-center justify-center transition">
            <ZoomIn className="w-6 h-6 text-white" />
          </div>
        </div>
      );
    }

    // 3. OVAL PORTRAIT
    if (shape === 'oval') {
      return (
        <div
          onClick={() => onPhotoClick?.(photo.url)}
          className={`relative rounded-[50%] overflow-hidden shadow-2xl ring-4 ring-amber-400/50 p-1.5 flex items-center justify-center bg-slate-900/10 cursor-pointer group ${options?.className || 'w-48 h-64 '}`}
        >
          <img
            src={photo.url}
            alt=""
            className="absolute inset-0 w-full h-full object-cover blur-md opacity-30 scale-125 pointer-events-none"
          />
          <img
            src={photo.url}
            alt={photo.caption || 'Photo'}
            className={`${fitClass} rounded-[50%] drop-shadow-md group-hover:scale-102 transition-transform duration-300`}
            style={{ filter: filterCss }}
          />
          <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 flex items-center justify-center rounded-[50%] transition">
            <ZoomIn className="w-6 h-6 text-white" />
          </div>
        </div>
      );
    }

    // 4. HEART FRAME
    if (shape === 'heart') {
      return (
        <div
          onClick={() => onPhotoClick?.(photo.url)}
          className={`relative rounded-3xl overflow-hidden shadow-2xl ring-4 ring-rose-400/60 p-2 flex items-center justify-center bg-gradient-to-tr from-pink-500/20 to-rose-500/20 cursor-pointer group ${options?.className || 'w-52 h-52'}`}
        >
          <img
            src={photo.url}
            alt=""
            className="absolute inset-0 w-full h-full object-cover blur-md opacity-35 scale-125 pointer-events-none"
          />
          <img
            src={photo.url}
            alt={photo.caption || 'Photo'}
            className={`${fitClass} rounded-2xl drop-shadow-md group-hover:scale-102 transition-transform duration-300`}
            style={{ filter: filterCss }}
          />
          <div className="absolute top-2 right-2 text-rose-500 drop-shadow-sm pointer-events-none">
            <Heart className="w-5 h-5 fill-rose-500 text-rose-500" />
          </div>
          <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 flex items-center justify-center rounded-3xl transition">
            <ZoomIn className="w-6 h-6 text-white" />
          </div>
        </div>
      );
    }

    // 5. STAR CREST
    if (shape === 'star') {
      return (
        <div
          onClick={() => onPhotoClick?.(photo.url)}
          className={`relative rounded-3xl overflow-hidden shadow-2xl ring-4 ring-amber-400/70 p-2 flex items-center justify-center bg-gradient-to-tr from-amber-500/20 to-yellow-500/20 cursor-pointer group ${options?.className || 'w-52 h-52'}`}
        >
          <img
            src={photo.url}
            alt=""
            className="absolute inset-0 w-full h-full object-cover blur-md opacity-35 scale-125 pointer-events-none"
          />
          <img
            src={photo.url}
            alt={photo.caption || 'Photo'}
            className={`${fitClass} rounded-2xl drop-shadow-md group-hover:scale-102 transition-transform duration-300`}
            style={{ filter: filterCss }}
          />
          <div className="absolute top-2 right-2 text-amber-500 drop-shadow-sm pointer-events-none">
            <Star className="w-5 h-5 fill-amber-400 text-amber-500" />
          </div>
          <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 flex items-center justify-center rounded-3xl transition">
            <ZoomIn className="w-6 h-6 text-white" />
          </div>
        </div>
      );
    }

    // 6. SCALLOPED BADGE
    if (shape === 'scallop') {
      return (
        <div
          onClick={() => onPhotoClick?.(photo.url)}
          className={`relative rounded-[32px] overflow-hidden shadow-2xl ring-4 ring-purple-400/60 p-2 flex items-center justify-center bg-gradient-to-tr from-purple-500/20 to-indigo-500/20 cursor-pointer group ${options?.className || 'w-52 h-52'}`}
        >
          <img
            src={photo.url}
            alt=""
            className="absolute inset-0 w-full h-full object-cover blur-md opacity-35 scale-125 pointer-events-none"
          />
          <img
            src={photo.url}
            alt={photo.caption || 'Photo'}
            className={`${fitClass} rounded-2xl drop-shadow-md group-hover:scale-102 transition-transform duration-300`}
            style={{ filter: filterCss }}
          />
          <div className="absolute top-2 right-2 text-purple-500 drop-shadow-sm pointer-events-none">
            <Sparkles className="w-5 h-5 text-purple-400" />
          </div>
          <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 flex items-center justify-center rounded-[32px] transition">
            <ZoomIn className="w-6 h-6 text-white" />
          </div>
        </div>
      );
    }

    // 7. ORGANIC BLOB
    if (shape === 'blob') {
      return (
        <div
          onClick={() => onPhotoClick?.(photo.url)}
          className={`relative rounded-[50%_40%_30%_60%/40%_50%_60%_30%] overflow-hidden shadow-2xl ring-4 ring-teal-400/50 p-2 flex items-center justify-center bg-gradient-to-tr from-teal-500/20 to-emerald-500/20 cursor-pointer group ${options?.className || 'w-52 h-52'}`}
        >
          <img
            src={photo.url}
            alt=""
            className="absolute inset-0 w-full h-full object-cover blur-md opacity-35 scale-125 pointer-events-none"
          />
          <img
            src={photo.url}
            alt={photo.caption || 'Photo'}
            className={`${fitClass} drop-shadow-md group-hover:scale-102 transition-transform duration-300`}
            style={{ filter: filterCss }}
          />
          <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 flex items-center justify-center transition">
            <ZoomIn className="w-6 h-6 text-white" />
          </div>
        </div>
      );
    }

    // 8. POLAROID
    if (shape === 'polaroid') {
      return (
        <div
          onClick={() => onPhotoClick?.(photo.url)}
          className={`bg-white p-2.5 pb-5 rounded-sm shadow-xl border border-slate-200/80 cursor-pointer group relative flex flex-col items-center ${options?.className || 'w-full'}`}
        >
          <div className="absolute -top-2 left-1/2 -translate-x-1/2 w-10 h-3.5 bg-amber-100/70 border-b border-amber-200/40 rotate-1 shadow-xs pointer-events-none" />
          <div className="relative w-full aspect-square bg-slate-900/10 overflow-hidden flex items-center justify-center p-1">
            <img
              src={photo.url}
              alt=""
              className="absolute inset-0 w-full h-full object-cover blur-sm opacity-25 scale-110 pointer-events-none"
            />
            <img
              src={photo.url}
              alt={photo.caption || 'Polaroid'}
              className="relative max-w-full max-h-full object-contain shadow-xs group-hover:scale-102 transition-transform"
              style={{ filter: filterCss }}
            />
          </div>
          {photo.caption && (
            <p className="text-[10px] text-slate-700 font-serif italic mt-2 text-center truncate w-full px-1">
              {photo.caption}
            </p>
          )}
        </div>
      );
    }

    // 9. STAMP
    if (shape === 'stamp') {
      return (
        <div
          onClick={() => onPhotoClick?.(photo.url)}
          className={`p-3 bg-white shadow-xl border-4 border-dashed border-stone-300 rounded-sm relative cursor-pointer group flex flex-col items-center ${options?.className || 'w-full'}`}
        >
          <div className="absolute top-2 right-2 text-[9px] font-bold text-amber-800/60 uppercase border border-amber-800/40 px-1 py-0.5 rounded-xs rotate-6 pointer-events-none">
            AIR MAIL
          </div>
          <div className="relative w-full aspect-[4/3] bg-stone-100 overflow-hidden flex items-center justify-center p-1">
            <img
              src={photo.url}
              alt=""
              className="absolute inset-0 w-full h-full object-cover blur-sm opacity-25 scale-110 pointer-events-none"
            />
            <img
              src={photo.url}
              alt={photo.caption || 'Stamp'}
              className="relative max-w-full max-h-full object-contain drop-shadow-xs group-hover:scale-102 transition-transform"
              style={{ filter: filterCss }}
            />
          </div>
          {photo.caption && (
            <p className="text-[10px] text-stone-600 font-serif mt-1.5 text-center truncate w-full">
              ★ {photo.caption} ★
            </p>
          )}
        </div>
      );
    }

    // DEFAULT RECTANGULAR FRAME
    return (
      <div
        onClick={() => onPhotoClick?.(photo.url)}
        className={`relative rounded-xl overflow-hidden shadow-md ring-1 ring-black/10 cursor-pointer group bg-slate-900/10 flex items-center justify-center p-1.5 ${options?.className || 'w-full flex-1'}`}
      >
        <img
          src={photo.url}
          alt=""
          className="absolute inset-0 w-full h-full object-cover blur-md opacity-25 scale-110 pointer-events-none"
        />
        <img
          src={photo.url}
          alt={photo.caption || 'Photo'}
          className={`${fitClass} rounded-lg shadow-sm group-hover:scale-102 transition-transform duration-300`}
          style={{ filter: filterCss }}
        />
        <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 flex items-center justify-center transition">
          <ZoomIn className="w-5 h-5 text-white" />
        </div>
        {options?.showCaption && photo.caption && (
          <div className="absolute bottom-1 left-2 bg-black/70 backdrop-blur-xs text-white px-2 py-0.5 rounded text-[9px]">
            {photo.caption}
          </div>
        )}
      </div>
    );
  };

  // --- COVER PAGE ---
  if (isCover || page.layout === 'cover') {
    return (
      <div className="flex-1 flex flex-col items-center justify-between p-4 text-center relative z-10 w-full h-full">
        <div className="w-full flex flex-col items-center">
          <div className="w-12 h-0.5 bg-current opacity-40 mb-2" />
          <span className="text-[10px] tracking-widest uppercase opacity-80 mb-0.5">
            Exclusive Photobook
          </span>
          <h2 className="text-xl font-black tracking-tight mb-1 leading-tight">
            {page.title || bookTitle || 'Our Memories'}
          </h2>
          {page.subtitle && (
            <p className="text-xs opacity-90 font-medium max-w-[280px]">
              {page.subtitle}
            </p>
          )}
        </div>

        {photos[0] && (
          <div className="w-full flex-1 max-h-[250px] my-1 flex items-center justify-center min-h-0">
            {renderSinglePhotoFrame(photos[0], 0, {
              className: 'w-full h-full max-h-[250px] ring-2 ring-white/30',
            })}
          </div>
        )}

        <div className="w-full flex flex-col items-center shrink-0">
          {page.notes && (
            <p className="text-[11px] opacity-80 italic max-w-[280px]">
              "{page.notes}"
            </p>
          )}
          <p className="text-[10px] opacity-60 mt-0.5">Created by {authorName || 'PhotoBook'}</p>
        </div>
      </div>
    );
  }

  // --- BACK COVER ---
  if (isBackCover || page.layout === 'back-cover') {
    return (
      <div className="flex-1 min-h-0 flex flex-col items-center justify-between p-3 text-center relative z-10 w-full h-full overflow-hidden">
        <div className="w-full flex flex-col items-center shrink-0">
          <Heart className="w-6 h-6 text-rose-400 mb-1 animate-pulse" />
          <h3 className="text-base font-bold mb-0.5">{page.title || 'The End'}</h3>
          {page.subtitle && (
            <p className="text-xs opacity-90 max-w-[260px]">{page.subtitle}</p>
          )}
        </div>

        {photos[0] && (
          <div className="w-full flex-1 max-h-[220px] my-1 flex items-center justify-center min-h-0">
            {renderSinglePhotoFrame(photos[0], 0, {
              className: 'w-full h-full max-h-[220px] ring-2 ring-white/30',
            })}
          </div>
        )}

        <div className="w-full flex flex-col items-center shrink-0">
          {page.notes && (
            <p className="text-xs italic opacity-80 max-w-[240px]">
              {page.notes}
            </p>
          )}
          <div className="mt-2 pt-1 border-t border-white/20 w-3/4 text-[10px] opacity-60">
            Preserved with PhotoBook • Digital Heirloom
          </div>
        </div>
      </div>
    );
  }

  // --- INSIDE PAGES (30 DESIGNS) ---
  return (
    <div className="flex-1 min-h-0 flex flex-col justify-between p-2.5 relative z-10 text-slate-800 w-full h-full overflow-hidden">
      {/* Page Header (Title + Subtitle) */}
      {(page.title || page.subtitle) && (
        <div className="mb-0.5 text-center shrink-0">
          {page.title && (
            <h3 className="text-xs font-bold tracking-tight text-slate-900 leading-tight truncate">
              {page.title}
            </h3>
          )}
          {page.subtitle && (
            <p className="text-[10px] text-slate-500 truncate">{page.subtitle}</p>
          )}
        </div>
      )}

      {/* DYNAMIC LAYOUT SWITCHER */}
      <div className="flex-1 min-h-0 flex flex-col justify-center w-full overflow-hidden my-auto">
        {/* 1. SINGLE FULL */}
        {page.layout === 'single-full' && (
          <div className="flex-1 min-h-0 flex flex-col items-center justify-center w-full h-full">
            {renderSinglePhotoFrame(photos[0], 0, { className: 'w-full flex-1 min-h-[160px] max-h-full' })}
            {photos[0]?.caption && (
              <p className="text-[10px] font-medium text-slate-600 mt-0.5 text-center italic shrink-0">
                {photos[0].caption}
              </p>
            )}
          </div>
        )}

        {/* 2. ROUND CENTER (HERO CIRCLE) */}
        {page.layout === 'round-center' && (
          <div className="flex-1 min-h-0 flex flex-col items-center justify-center gap-1.5">
            {renderSinglePhotoFrame(photos[0], 0, {
              shape: 'circle',
              className: 'w-40 h-40 max-h-[272px] max-w-[272px] aspect-square',
            })}
            {photos[0]?.caption && (
              <p className="text-[11px] font-semibold text-slate-700 italic text-center shrink-0">
                "{photos[0].caption}"
              </p>
            )}
          </div>
        )}

        {/* 3. ROUND DUO (2 CIRCULAR BUBBLES) */}
        {page.layout === 'round-duo' && (
          <div className="flex-1 min-h-0 flex flex-col items-center justify-center gap-2">
            <div className="flex items-center justify-center gap-2.5">
              {renderSinglePhotoFrame(photos[0], 0, { shape: 'circle', className: 'w-26 h-26 max-h-[176px] max-w-[176px] aspect-square' })}
              {renderSinglePhotoFrame(photos[1], 1, { shape: 'circle', className: 'w-26 h-26 max-h-[176px] max-w-[176px] aspect-square' })}
            </div>
            {(photos[0]?.caption || photos[1]?.caption) && (
              <p className="text-[9px] text-slate-600 text-center italic shrink-0">
                {[photos[0]?.caption, photos[1]?.caption].filter(Boolean).join(' • ')}
              </p>
            )}
          </div>
        )}

        {/* 4. ROUND TRIO (3 CIRCLE CLUSTER) */}
        {page.layout === 'round-trio' && (
          <div className="flex-1 min-h-0 flex flex-col items-center justify-center gap-1.5">
            {renderSinglePhotoFrame(photos[0], 0, { shape: 'circle', className: 'w-24 h-24 max-h-[160px] max-w-[160px] aspect-square' })}
            <div className="flex items-center gap-2.5">
              {renderSinglePhotoFrame(photos[1], 1, { shape: 'circle', className: 'w-18 h-18 max-h-[120px] max-w-[120px] aspect-square' })}
              {renderSinglePhotoFrame(photos[2], 2, { shape: 'circle', className: 'w-18 h-18 max-h-[120px] max-w-[120px] aspect-square' })}
            </div>
          </div>
        )}

        {/* 5. ROUND QUAD (4 CIRCLE BUBBLE CLUSTER) */}
        {page.layout === 'round-quad' && (
          <div className="flex-1 min-h-0 flex flex-col items-center justify-center gap-1.5">
            <div className="grid grid-cols-2 gap-2">
              {renderSinglePhotoFrame(photos[0], 0, { shape: 'circle', className: 'w-18 h-18 max-h-[112px] max-w-[112px] aspect-square' })}
              {renderSinglePhotoFrame(photos[1], 1, { shape: 'circle', className: 'w-18 h-18 max-h-[112px] max-w-[112px] aspect-square' })}
              {renderSinglePhotoFrame(photos[2], 2, { shape: 'circle', className: 'w-18 h-18 max-h-[112px] max-w-[112px] aspect-square' })}
              {renderSinglePhotoFrame(photos[3], 3, { shape: 'circle', className: 'w-18 h-18 max-h-[112px] max-w-[112px] aspect-square' })}
            </div>
          </div>
        )}

        {/* 6. ARCH PORTAL (DOME) */}
        {page.layout === 'arch-portal' && (
          <div className="flex-1 min-h-0 flex flex-col items-center justify-center">
            {renderSinglePhotoFrame(photos[0], 0, {
              shape: 'arch',
              className: 'w-full flex-1 min-h-[160px] max-h-[280px]',
            })}
            {photos[0]?.caption && (
              <p className="text-[10px] font-medium text-slate-600 mt-0.5 text-center shrink-0">
                {photos[0].caption}
              </p>
            )}
          </div>
        )}

        {/* 7. TWIN ARCHES DUO */}
        {page.layout === 'arched-duo' && (
          <div className="flex-1 min-h-0 flex flex-col items-center justify-center gap-1.5">
            <div className="grid grid-cols-2 gap-2 w-full flex-1 max-h-[260px] min-h-0">
              {renderSinglePhotoFrame(photos[0], 0, { shape: 'arch', className: 'w-full h-full' })}
              {renderSinglePhotoFrame(photos[1], 1, { shape: 'arch', className: 'w-full h-full' })}
            </div>
            {(photos[0]?.caption || photos[1]?.caption) && (
              <p className="text-[9px] text-slate-600 text-center italic shrink-0">
                {[photos[0]?.caption, photos[1]?.caption].filter(Boolean).join(' • ')}
              </p>
            )}
          </div>
        )}

        {/* 8. OVAL PORTRAIT (VICTORIAN) */}
        {page.layout === 'oval-portrait' && (
          <div className="flex-1 min-h-0 flex flex-col items-center justify-center gap-1.5">
            {renderSinglePhotoFrame(photos[0], 0, {
              shape: 'oval',
              className: 'w-36 h-50 max-h-[256px] max-w-[256px]',
            })}
            {photos[0]?.caption && (
              <p className="text-[10px] font-serif text-slate-700 italic text-center shrink-0">
                {photos[0].caption}
              </p>
            )}
          </div>
        )}

        {/* 9. ROMANTIC HEART FRAME */}
        {page.layout === 'heart-frame' && (
          <div className="flex-1 min-h-0 flex flex-col items-center justify-center gap-1.5">
            {renderSinglePhotoFrame(photos[0], 0, {
              shape: 'heart',
              className: 'w-40 h-40 max-h-[256px] max-w-[256px]',
            })}
            {photos[0]?.caption && (
              <p className="text-[10px] font-semibold text-rose-950 italic text-center shrink-0">
                ❤️ {photos[0].caption}
              </p>
            )}
          </div>
        )}

        {/* 10. STAR CREST MEDAL */}
        {page.layout === 'star-crest' && (
          <div className="flex-1 min-h-0 flex flex-col items-center justify-center gap-1.5">
            {renderSinglePhotoFrame(photos[0], 0, {
              shape: 'star',
              className: 'w-40 h-40 max-h-[256px] max-w-[256px]',
            })}
            {photos[0]?.caption && (
              <p className="text-[10px] font-semibold text-amber-950 italic text-center shrink-0">
                ⭐ {photos[0].caption}
              </p>
            )}
          </div>
        )}

        {/* 11. SCALLOPED BADGE MEDALLION */}
        {page.layout === 'scalloped-badge' && (
          <div className="flex-1 min-h-0 flex flex-col items-center justify-center gap-1.5">
            {renderSinglePhotoFrame(photos[0], 0, {
              shape: 'scallop',
              className: 'w-40 h-40 max-h-[256px] max-w-[256px]',
            })}
            {photos[0]?.caption && (
              <p className="text-[10px] font-semibold text-purple-950 italic text-center shrink-0">
                🏵️ {photos[0].caption}
              </p>
            )}
          </div>
        )}

        {/* 12. ORGANIC PEBBLE BLOB */}
        {page.layout === 'organic-blob' && (
          <div className="flex-1 min-h-0 flex flex-col items-center justify-center gap-1.5">
            {renderSinglePhotoFrame(photos[0], 0, {
              shape: 'blob',
              className: 'w-40 h-40 max-h-[256px] max-w-[256px]',
            })}
            {photos[0]?.caption && (
              <p className="text-[10px] font-semibold text-teal-950 italic text-center shrink-0">
                💧 {photos[0].caption}
              </p>
            )}
          </div>
        )}

        {/* 13. DIAMOND RHOMBUS */}
        {page.layout === 'diamond-center' && (
          <div className="flex-1 min-h-0 flex flex-col items-center justify-center gap-1.5">
            <div className="relative w-40 h-40 max-h-[240px] max-w-[240px] flex items-center justify-center p-2">
              <div
                onClick={() => photos[0] && onPhotoClick?.(photos[0].url)}
                className="w-32 h-32 rounded-2xl rotate-45 border-4 border-amber-500/40 shadow-xl overflow-hidden flex items-center justify-center cursor-pointer bg-slate-900/10 group"
              >
                {photos[0] && (
                  <div className="-rotate-45 w-[140%] h-[140%] flex items-center justify-center relative">
                    <img
                      src={photos[0].url}
                      alt=""
                      className="absolute inset-0 w-full h-full object-cover blur-sm opacity-25 scale-110 pointer-events-none"
                    />
                    <img
                      src={photos[0].url}
                      alt="Diamond"
                      className="relative max-w-full max-h-full object-contain drop-shadow-sm group-hover:scale-105 transition-transform"
                      style={{ filter: getPhotoFilterStyle(photos[0].filter) }}
                    />
                  </div>
                )}
              </div>
            </div>
            {photos[0]?.caption && (
              <p className="text-[10px] font-medium text-slate-600 text-center shrink-0">
                💎 {photos[0].caption}
              </p>
            )}
          </div>
        )}

        {/* 14. HONEYCOMB HEX DUO */}
        {page.layout === 'hex-cluster' && (
          <div className="flex-1 min-h-0 flex flex-col items-center justify-center gap-2">
            <div className="flex items-center justify-center gap-2.5">
              {renderSinglePhotoFrame(photos[0], 0, {
                className: 'w-28 h-28 max-h-[176px] max-w-[176px] rounded-3xl border-2 border-indigo-400/40 shadow-lg',
              })}
              {renderSinglePhotoFrame(photos[1], 1, {
                className: 'w-28 h-28 max-h-[176px] max-w-[176px] rounded-3xl border-2 border-pink-400/40 shadow-lg',
              })}
            </div>
            {(photos[0]?.caption || photos[1]?.caption) && (
              <p className="text-[9px] text-slate-600 text-center shrink-0">
                {[photos[0]?.caption, photos[1]?.caption].filter(Boolean).join(' • ')}
              </p>
            )}
          </div>
        )}

        {/* 15. CIRCLE & CAPTION QUOTE */}
        {page.layout === 'circle-caption' && (
          <div className="flex-1 min-h-0 flex flex-col items-center justify-center gap-2">
            {renderSinglePhotoFrame(photos[0], 0, {
              shape: 'circle',
              className: 'w-32 h-32 max-h-[176px] max-w-[176px]',
            })}
            <div className="p-2 bg-white/70 rounded-xl border border-slate-200/80 shadow-sm max-w-[260px] text-center shrink-0">
              <Feather className="w-3.5 h-3.5 text-indigo-500 mx-auto mb-0.5" />
              <p className="text-[11px] font-serif italic text-slate-700 leading-snug line-clamp-2">
                {page.notes || photos[0]?.caption || 'Some moments are etched in time, never to fade.'}
              </p>
            </div>
          </div>
        )}

        {/* 16. 2 POLAROIDS VINTAGE */}
        {page.layout === 'polaroid-duo' && (
          <div className="flex-1 flex flex-col items-center justify-center gap-2 min-h-0 p-1">
            <div className="grid grid-cols-2 gap-3 w-full items-center">
              <div className="-rotate-3 hover:rotate-0 transition-transform">
                {renderSinglePhotoFrame(photos[0], 0, { shape: 'polaroid' })}
              </div>
              <div className="rotate-3 hover:rotate-0 transition-transform">
                {renderSinglePhotoFrame(photos[1], 1, { shape: 'polaroid' })}
              </div>
            </div>
          </div>
        )}

        {/* 17. 3 POLAROIDS STACK */}
        {page.layout === 'polaroid-trio' && (
          <div className="flex-1 flex flex-col items-center justify-center gap-2 min-h-0 p-1">
            <div className="grid grid-cols-3 gap-2 w-full items-center">
              <div className="-rotate-4 hover:rotate-0 transition-transform">
                {renderSinglePhotoFrame(photos[0], 0, { shape: 'polaroid' })}
              </div>
              <div className="rotate-1 hover:rotate-0 transition-transform">
                {renderSinglePhotoFrame(photos[1], 1, { shape: 'polaroid' })}
              </div>
              <div className="rotate-4 hover:rotate-0 transition-transform">
                {renderSinglePhotoFrame(photos[2], 2, { shape: 'polaroid' })}
              </div>
            </div>
          </div>
        )}

        {/* 18. 35MM FILMSTRIP REEL HORIZONTAL */}
        {page.layout === 'filmstrip-3' && (
          <div className="flex-1 flex flex-col justify-center min-h-0 p-1">
            <div className="bg-slate-950 rounded-xl p-2.5 shadow-2xl border border-slate-800 flex flex-col gap-2 relative">
              <div className="flex justify-between px-1 opacity-70">
                {[...Array(10)].map((_, i) => (
                  <div key={i} className="w-2.5 h-1.5 bg-white/80 rounded-2xs" />
                ))}
              </div>
              <div className="grid grid-cols-3 gap-2 py-1">
                {[0, 1, 2].map((idx) => (
                  <div key={idx} className="aspect-[4/3] bg-black/60 rounded-sm overflow-hidden flex items-center justify-center p-0.5 relative group cursor-pointer" onClick={() => photos[idx] && onPhotoClick?.(photos[idx].url)}>
                    {photos[idx] ? (
                      <>
                        <img src={photos[idx].url} alt="" className="absolute inset-0 w-full h-full object-cover blur-xs opacity-30" />
                        <img src={photos[idx].url} alt="" className="relative max-w-full max-h-full object-contain" style={{ filter: getPhotoFilterStyle(photos[idx].filter) }} />
                      </>
                    ) : (
                      <span className="text-[8px] text-slate-500">#{idx + 1}</span>
                    )}
                  </div>
                ))}
              </div>
              <div className="flex justify-between px-1 opacity-70">
                {[...Array(10)].map((_, i) => (
                  <div key={i} className="w-2.5 h-1.5 bg-white/80 rounded-2xs" />
                ))}
              </div>
            </div>
            {photos[0]?.caption && (
              <p className="text-[10px] text-slate-500 text-center mt-1">🎞️ {photos[0].caption}</p>
            )}
          </div>
        )}

        {/* 19. VERTICAL FILM REEL */}
        {page.layout === 'filmstrip-vertical' && (
          <div className="flex-1 flex items-center justify-center gap-3 min-h-0 p-1">
            <div className="bg-slate-950 rounded-xl p-2 shadow-2xl border border-slate-800 flex flex-col gap-1.5 w-40">
              {[0, 1, 2].map((idx) => (
                <div key={idx} className="aspect-[4/3] bg-black/60 rounded-sm overflow-hidden flex items-center justify-center p-0.5 relative cursor-pointer" onClick={() => photos[idx] && onPhotoClick?.(photos[idx].url)}>
                  {photos[idx] ? (
                    <>
                      <img src={photos[idx].url} alt="" className="absolute inset-0 w-full h-full object-cover blur-xs opacity-30" />
                      <img src={photos[idx].url} alt="" className="relative max-w-full max-h-full object-contain" style={{ filter: getPhotoFilterStyle(photos[idx].filter) }} />
                    </>
                  ) : (
                    <span className="text-[8px] text-slate-500">#{idx + 1}</span>
                  )}
                </div>
              ))}
            </div>
            <div className="flex-1 flex flex-col justify-center gap-2 p-2 bg-white/70 rounded-xl border border-slate-200">
              <span className="text-[9px] font-bold uppercase tracking-wider text-indigo-600">Reel Memoir</span>
              <p className="text-xs font-serif italic text-slate-700 leading-relaxed">
                {page.notes || 'Moments captured in sequence, like frames of a timeless movie.'}
              </p>
            </div>
          </div>
        )}

        {/* 20. POSTAGE STAMP VINTAGE */}
        {page.layout === 'stamp-vintage' && (
          <div className="flex-1 flex flex-col items-center justify-center min-h-0 p-2">
            <div className="w-full max-w-[280px]">
              {renderSinglePhotoFrame(photos[0], 0, { shape: 'stamp' })}
            </div>
          </div>
        )}

        {/* 21. SPLIT 2 VERTICAL */}
        {page.layout === 'split-2-v' && (
          <div className="flex-1 grid grid-cols-2 gap-2 items-center min-h-0">
            {photos.slice(0, 2).map((ph, idx) => (
              <div key={idx} className="flex flex-col h-full justify-center min-h-0">
                {renderSinglePhotoFrame(ph, idx, { className: 'flex-1 min-h-[180px] max-h-[340px]', showCaption: true })}
                {ph.caption && (
                  <p className="text-[9px] text-slate-600 mt-1 text-center font-medium truncate">
                    {ph.caption}
                  </p>
                )}
              </div>
            ))}
          </div>
        )}

        {/* 22. SPLIT 2 HORIZONTAL */}
        {page.layout === 'split-2-h' && (
          <div className="flex-1 grid grid-rows-2 gap-2 min-h-0">
            {photos.slice(0, 2).map((ph, idx) => (
              <div key={idx} className="w-full h-full min-h-[110px] flex items-center justify-center">
                {renderSinglePhotoFrame(ph, idx, { className: 'w-full h-full min-h-[110px]', showCaption: true })}
              </div>
            ))}
          </div>
        )}

        {/* 23. GRID 3 (1 HERO + 2 SIDE) */}
        {page.layout === 'grid-3' && (
          <div className="flex-1 grid grid-cols-2 gap-2 items-center min-h-0">
            <div className="h-full flex items-center justify-center">
              {renderSinglePhotoFrame(photos[0], 0, { className: 'w-full h-full min-h-[220px]', showCaption: true })}
            </div>
            <div className="grid grid-rows-2 gap-2 h-full">
              {renderSinglePhotoFrame(photos[1], 1, { className: 'w-full h-full min-h-[105px]', showCaption: true })}
              {renderSinglePhotoFrame(photos[2], 2, { className: 'w-full h-full min-h-[105px]', showCaption: true })}
            </div>
          </div>
        )}

        {/* 24. QUAD GRID (2x2) */}
        {page.layout === 'grid-4' && (
          <div className="flex-1 grid grid-cols-2 grid-rows-2 gap-2 p-0.5 min-h-0">
            {photos.slice(0, 4).map((ph, idx) => (
              <div key={idx} className="w-full h-full min-h-[110px] max-h-[180px] flex items-center justify-center">
                {renderSinglePhotoFrame(ph, idx, { className: 'w-full h-full', showCaption: true })}
              </div>
            ))}
          </div>
        )}

        {/* 25. MOSAIC GRID 6 (2x3) */}
        {page.layout === 'grid-6' && (
          <div className="flex-1 grid grid-cols-3 grid-rows-2 gap-1.5 p-0.5 min-h-0">
            {[0, 1, 2, 3, 4, 5].map((idx) => (
              <div key={idx} className="w-full h-full min-h-[85px] max-h-[130px] flex items-center justify-center">
                {renderSinglePhotoFrame(photos[idx], idx, { className: 'w-full h-full' })}
              </div>
            ))}
          </div>
        )}

        {/* 26. EDITORIAL MAGAZINE FEATURE */}
        {page.layout === 'magazine-feature' && (
          <div className="flex-1 flex flex-col justify-between min-h-0 gap-2 p-1">
            <div className="border-b-2 border-slate-900 pb-1 flex items-center justify-between">
              <span className="text-[9px] font-black tracking-widest uppercase text-slate-800">MEMOIR / ISSUE 01</span>
              <span className="text-[9px] font-serif italic text-slate-500">Curated Moments</span>
            </div>
            <div className="flex-1 min-h-[180px] max-h-[300px]">
              {renderSinglePhotoFrame(photos[0], 0, { className: 'w-full h-full' })}
            </div>
            <div className="bg-slate-100/80 p-2.5 rounded-lg border-l-4 border-indigo-600">
              <p className="text-[11px] font-serif leading-relaxed text-slate-800 italic">
                {page.notes || 'In the quiet glow of everyday life, these memories stay golden.'}
              </p>
            </div>
          </div>
        )}

        {/* 27. ASYMMETRIC COLLAGE */}
        {page.layout === 'collage-asymmetric' && (
          <div className="flex-1 flex flex-col gap-2 min-h-0 p-1">
            <div className="flex-1 min-h-[140px]">
              {renderSinglePhotoFrame(photos[0], 0, { className: 'w-full h-full' })}
            </div>
            <div className="grid grid-cols-2 gap-2 h-28 shrink-0">
              {renderSinglePhotoFrame(photos[1], 1, { className: 'w-full h-full' })}
              {renderSinglePhotoFrame(photos[2], 2, { className: 'w-full h-full' })}
            </div>
          </div>
        )}

        {/* 28. STORY TEXT & LETTER NOTE */}
        {page.layout === 'story-text' && (
          <div className="flex-1 flex flex-col justify-center items-center text-center p-5 bg-white/70 rounded-2xl border border-slate-200 shadow-sm">
            <div className="w-10 h-10 rounded-full bg-indigo-50 text-indigo-600 flex items-center justify-center mb-3 shadow-xs">
              <BookOpen className="w-5 h-5" />
            </div>
            <p className="text-xs leading-relaxed text-slate-700 italic font-serif max-w-[280px]">
              {page.notes || 'Capture the heartfelt vows, spontaneous laughter, and unforgettable journeys here.'}
            </p>
            <div className="w-16 h-0.5 bg-indigo-200 mt-4" />
          </div>
        )}
      </div>

      {/* Page Footer (Title and Page Number) */}
      <div className="pt-1.5 flex items-center justify-between text-[10px] text-slate-400 border-t border-slate-200/50 shrink-0">
        <span className="truncate max-w-[200px]">{bookTitle || 'PhotoBook'}</span>
        <span className="font-semibold text-slate-600">
          Page {page.pageNumber}
        </span>
      </div>
    </div>
  );
};
