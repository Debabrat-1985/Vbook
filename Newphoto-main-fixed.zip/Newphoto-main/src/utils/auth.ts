import { UserProfile } from '../types';

const STORAGE_KEY_AUTH = 'photobook_auth_session_v2';
const STORAGE_KEY_REGISTERED_USERS = 'photobook_registered_users_v2';

export interface StoredAccount {
  id: string;
  name: string;
  email: string;
  passwordHash: string; // stored password representation
  avatarUrl: string;
  tier: 'free' | 'pro';
  bonusCredits: number;
  createdAt: number;
}

export function getRegisteredUsers(): StoredAccount[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_REGISTERED_USERS);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function saveRegisteredUsers(users: StoredAccount[]) {
  try {
    localStorage.setItem(STORAGE_KEY_REGISTERED_USERS, JSON.stringify(users));
  } catch {
    //
  }
}

export function getAuthSession(): UserProfile | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_AUTH);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    return parsed && parsed.email ? parsed : null;
  } catch {
    return null;
  }
}

export function setAuthSession(user: UserProfile | null) {
  try {
    if (!user) {
      localStorage.removeItem(STORAGE_KEY_AUTH);
    } else {
      localStorage.setItem(STORAGE_KEY_AUTH, JSON.stringify(user));
    }
  } catch {
    //
  }
}

// Generate avatar based on name initials or Unsplash
function getAvatarForUser(name: string): string {
  const encoded = encodeURIComponent(name || 'User');
  return `https://ui-avatars.com/api/?name=${encoded}&background=6366f1&color=ffffff&bold=true&rounded=true`;
}

export function signUpUser(
  name: string,
  email: string,
  password: string
): { success: boolean; user?: UserProfile; error?: string } {
  const cleanName = name.trim();
  const cleanEmail = email.trim().toLowerCase();

  if (!cleanName) {
    return { success: false, error: 'Kripya apna poora naam enter karein (Please enter your name)' };
  }
  if (!cleanEmail || !cleanEmail.includes('@') || !cleanEmail.includes('.')) {
    return { success: false, error: 'Valid email address enter karein' };
  }
  if (!password || password.length < 6) {
    return { success: false, error: 'Password kam se kam 6 characters ka hona chahiye' };
  }

  const registered = getRegisteredUsers();
  const existing = registered.find(u => u.email.toLowerCase() === cleanEmail);
  if (existing) {
    return {
      success: false,
      error: 'Ye email pehle se registered hai. Kripya Log In karein.',
    };
  }

  const newAccount: StoredAccount = {
    id: `usr_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
    name: cleanName,
    email: cleanEmail,
    passwordHash: password, // In client storage
    avatarUrl: getAvatarForUser(cleanName),
    tier: 'free',
    bonusCredits: 0,
    createdAt: Date.now(),
  };

  registered.push(newAccount);
  saveRegisteredUsers(registered);

  const profile: UserProfile = {
    id: newAccount.id,
    name: newAccount.name,
    email: newAccount.email,
    avatarUrl: newAccount.avatarUrl,
    isLoggedIn: true,
    tier: newAccount.tier,
    booksCreatedCount: 0,
    bonusCredits: 0,
  };

  setAuthSession(profile);
  return { success: true, user: profile };
}

export function loginUser(
  email: string,
  password: string
): { success: boolean; user?: UserProfile; error?: string } {
  const cleanEmail = email.trim().toLowerCase();

  if (!cleanEmail || !password) {
    return { success: false, error: 'Email aur password dono enter karein' };
  }

  const registered = getRegisteredUsers();
  const account = registered.find(u => u.email.toLowerCase() === cleanEmail);

  if (!account) {
    return {
      success: false,
      error: 'Account nahi mila. Pehle Naya Account banayein (Sign Up karein).',
    };
  }

  if (account.passwordHash !== password) {
    return {
      success: false,
      error: 'Galat password. Kripya dobara check karein.',
    };
  }

  const profile: UserProfile = {
    id: account.id,
    name: account.name,
    email: account.email,
    avatarUrl: account.avatarUrl || getAvatarForUser(account.name),
    isLoggedIn: true,
    tier: account.tier || 'free',
    booksCreatedCount: 0,
    bonusCredits: account.bonusCredits || 0,
  };

  setAuthSession(profile);
  return { success: true, user: profile };
}

export function loginWithGoogle(
  email = 'user@gmail.com',
  name = 'Google User'
): { success: boolean; user: UserProfile } {
  const cleanEmail = email.trim().toLowerCase();
  const registered = getRegisteredUsers();
  let account = registered.find(u => u.email.toLowerCase() === cleanEmail);

  if (!account) {
    account = {
      id: `usr_g_${Date.now()}`,
      name: name,
      email: cleanEmail,
      passwordHash: 'google_oauth_token',
      avatarUrl: getAvatarForUser(name),
      tier: 'free',
      bonusCredits: 0,
      createdAt: Date.now(),
    };
    registered.push(account);
    saveRegisteredUsers(registered);
  }

  const profile: UserProfile = {
    id: account.id,
    name: account.name,
    email: account.email,
    avatarUrl: account.avatarUrl,
    isLoggedIn: true,
    tier: account.tier,
    booksCreatedCount: 0,
    bonusCredits: account.bonusCredits || 0,
  };

  setAuthSession(profile);
  return { success: true, user: profile };
}

export function logoutUser() {
  setAuthSession(null);
}
