import { PhotoBook, UserProfile, UsageLimitConfig } from '../types';
import { getAuthSession, setAuthSession } from './auth';

const STORAGE_KEY_BOOKS = 'photobook_app_user_books_v2';
const STORAGE_KEY_LANG = 'photobook_app_lang_v1';

export const USAGE_LIMITS: UsageLimitConfig = {
  maxFreeBooks: 2,
  maxPagesPerBook: 10,
};

export function getUserProfile(): UserProfile | null {
  return getAuthSession();
}

export function saveUserProfile(user: UserProfile) {
  setAuthSession(user);
}

// Sample books used for template library and fallback
export const SAMPLE_BOOKS: PhotoBook[] = [
  {
    id: 'book-wedding-karan-priya',
    title: 'Karan & Priya ki Shaadi',
    subtitle: 'Celebrating Love, Family & Beautiful Moments',
    authorName: 'Priya & Karan',
    authorEmail: 'karanpriya@example.com',
    coverImage: 'https://images.unsplash.com/photo-1519741497674-611481863552?w=800&auto=format&fit=crop&q=80',
    theme: 'royal-gold',
    createdAt: Date.now() - 86400000 * 5,
    updatedAt: Date.now() - 86400000 * 2,
    isPublic: true,
    pages: [
      {
        id: 'p-cover',
        pageNumber: 1,
        layout: 'cover',
        title: 'Karan & Priya',
        subtitle: 'Our Wedding Chronicle • Udaipur, Rajasthan',
        notes: 'A journey that started with a spark and grew into a lifetime bond.',
        photos: [
          {
            id: 'ph-cov',
            url: 'https://images.unsplash.com/photo-1519741497674-611481863552?w=800&auto=format&fit=crop&q=80',
            caption: 'Karan & Priya • Forever & Always',
            filter: 'warm'
          }
        ]
      },
      {
        id: 'p-2',
        pageNumber: 2,
        layout: 'split-2-v',
        title: 'Haldi & Sangeet Beats',
        subtitle: 'Peela rang, dhol ki thap aur dher saara pyar!',
        notes: 'The courtyard echoed with laughter as turmeric was applied with blessings from grandparents.',
        photos: [
          {
            id: 'ph-2-1',
            url: 'https://images.unsplash.com/photo-1583939003579-730e3918a45a?w=800&auto=format&fit=crop&q=80',
            caption: 'Golden Haldi Glow',
            filter: 'warm'
          },
          {
            id: 'ph-2-2',
            url: 'https://images.unsplash.com/photo-1511285560929-80b456fea0bc?w=800&auto=format&fit=crop&q=80',
            caption: 'Dancing under the Fairy Lights',
            filter: 'normal'
          }
        ]
      },
      {
        id: 'p-3',
        pageNumber: 3,
        layout: 'single-full',
        title: 'Saat Phere & Vows',
        subtitle: 'Agnikund ke saamne 7 vachan',
        notes: 'Every prayer whispered under the starry night made this sacred bond eternal.',
        photos: [
          {
            id: 'ph-3-1',
            url: 'https://images.unsplash.com/photo-1606800052052-a08af7148866?w=800&auto=format&fit=crop&q=80',
            caption: 'The moment our hands and souls united',
            filter: 'vintage'
          }
        ]
      },
      {
        id: 'p-4',
        pageNumber: 4,
        layout: 'grid-4',
        title: 'Family & Friends Smiles',
        subtitle: 'Unforgettable candid moments with our favorite people',
        notes: 'Yaaron ki masti aur parivar ka aashirwaad.',
        photos: [
          {
            id: 'ph-4-1',
            url: 'https://images.unsplash.com/photo-1522673607200-164d1b6ce486?w=800&auto=format&fit=crop&q=80',
            caption: 'Bridesmaids laughter',
            filter: 'cool'
          },
          {
            id: 'ph-4-2',
            url: 'https://images.unsplash.com/photo-1529636798458-92182e662485?w=800&auto=format&fit=crop&q=80',
            caption: 'The Toast',
            filter: 'warm'
          },
          {
            id: 'ph-4-3',
            url: 'https://images.unsplash.com/photo-1469371670807-013ccf25f16a?w=800&auto=format&fit=crop&q=80',
            caption: 'Royal Mandap Flowers',
            filter: 'normal'
          },
          {
            id: 'ph-4-4',
            url: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=800&auto=format&fit=crop&q=80',
            caption: 'Priya smiling brightly',
            filter: 'warm'
          }
        ]
      },
      {
        id: 'p-5',
        pageNumber: 5,
        layout: 'story-text',
        title: 'To a Lifetime of Memories',
        subtitle: 'With love from all of us',
        notes: 'Thank you everyone for making our day so magical. This photobook preserves every teardrop, heartfelt smile, and song in our hearts.',
        photos: []
      },
      {
        id: 'p-back',
        pageNumber: 6,
        layout: 'back-cover',
        title: 'The Beginning of Forever',
        subtitle: 'Made with love • PhotoBook App',
        notes: 'Printed & preserved digitally with PhotoBook.',
        photos: [
          {
            id: 'ph-back',
            url: 'https://images.unsplash.com/photo-1519741497674-611481863552?w=800&auto=format&fit=crop&q=80',
            caption: 'Karan & Priya • 2026',
            filter: 'bw'
          }
        ]
      }
    ]
  },
  {
    id: 'book-trip-himachal-2026',
    title: 'Himachal & Manali Adventure',
    subtitle: 'Snow peaks, hot chai & endless mountain roads',
    authorName: 'Travel Crew',
    authorEmail: 'travel@example.com',
    coverImage: 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=800&auto=format&fit=crop&q=80',
    theme: 'vintage-leather',
    createdAt: Date.now() - 86400000 * 12,
    updatedAt: Date.now() - 86400000 * 4,
    isPublic: true,
    pages: [
      {
        id: 'p-hima-cover',
        pageNumber: 1,
        layout: 'cover',
        title: 'Into the Great Himalayas',
        subtitle: 'Solang Valley, Spiti & Rohtang Pass',
        notes: '7 days of pure wanderlust, maggi at 12,000 ft, and freezing winds.',
        photos: [
          {
            id: 'ph-hima-1',
            url: 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=800&auto=format&fit=crop&q=80',
            caption: 'First morning view from our cottage',
            filter: 'normal'
          }
        ]
      },
      {
        id: 'p-hima-2',
        pageNumber: 2,
        layout: 'split-2-h',
        title: 'Pine Forests & Pine Cones',
        subtitle: 'Trekking through old Manali trails',
        notes: 'Fresh mountain breeze and river Beas whispering on the trail.',
        photos: [
          {
            id: 'ph-hima-2-1',
            url: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?w=800&auto=format&fit=crop&q=80',
            caption: 'Alpine lake reflection',
            filter: 'cool'
          },
          {
            id: 'ph-hima-2-2',
            url: 'https://images.unsplash.com/photo-1517824806704-9040b037703b?w=800&auto=format&fit=crop&q=80',
            caption: 'Campfire and starry sky',
            filter: 'warm'
          }
        ]
      },
      {
        id: 'p-hima-back',
        pageNumber: 3,
        layout: 'back-cover',
        title: 'Pahadon ki Yaadein',
        subtitle: 'Until next time, mountains!',
        notes: 'Photobook crafted on Android with PhotoBook PWA.',
        photos: [
          {
            id: 'ph-hima-3',
            url: 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=800&auto=format&fit=crop&q=80',
            caption: 'Rohtang Pass memories',
            filter: 'bw'
          }
        ]
      }
    ]
  }
];

// Returns books belonging specifically to this user
export function getStoredBooks(userEmail?: string): PhotoBook[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_BOOKS);
    if (!raw) return [];
    const allBooks: PhotoBook[] = JSON.parse(raw);
    if (!Array.isArray(allBooks)) return [];
    if (!userEmail) return allBooks;
    return allBooks.filter(b => b.authorEmail?.toLowerCase() === userEmail.toLowerCase());
  } catch {
    return [];
  }
}

// Get all books in local storage
export function getAllStoredBooks(): PhotoBook[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_BOOKS);
    if (!raw) return [];
    const allBooks: PhotoBook[] = JSON.parse(raw);
    return Array.isArray(allBooks) ? allBooks : [];
  } catch {
    return [];
  }
}

// Save book locally and sync to server so shared links work on ANY device!
export function saveBook(book: PhotoBook): PhotoBook[] {
  const allBooks = getAllStoredBooks();
  const existingIdx = allBooks.findIndex(b => b.id === book.id);
  let updated: PhotoBook[];
  if (existingIdx >= 0) {
    updated = [...allBooks];
    updated[existingIdx] = { ...book, updatedAt: Date.now() };
  } else {
    updated = [{ ...book, updatedAt: Date.now() }, ...allBooks];
  }
  try {
    localStorage.setItem(STORAGE_KEY_BOOKS, JSON.stringify(updated));
  } catch {
    //
  }

  // Asynchronously sync book with backend so anyone with the share link can open it
  try {
    syncBookToServer(book).catch(() => {});
  } catch {
    // Non-blocking
  }

  return book.authorEmail
    ? updated.filter(b => b.authorEmail?.toLowerCase() === book.authorEmail?.toLowerCase())
    : updated;
}

export function deleteBook(id: string, userEmail?: string): PhotoBook[] {
  const allBooks = getAllStoredBooks();
  const updated = allBooks.filter(b => b.id !== id);
  try {
    localStorage.setItem(STORAGE_KEY_BOOKS, JSON.stringify(updated));
  } catch {
    //
  }

  // Delete from server too
  try {
    fetch(`/api/books/${id}`, { method: 'DELETE' }).catch(() => {});
  } catch {}

  return userEmail
    ? updated.filter(b => b.authorEmail?.toLowerCase() === userEmail.toLowerCase())
    : updated;
}

// Synchronous lookup (from local storage or sample books)
export function getBookById(id: string): PhotoBook | undefined {
  const allBooks = getAllStoredBooks();
  const found = allBooks.find(b => b.id === id);
  if (found) return found;
  return SAMPLE_BOOKS.find(b => b.id === id);
}

// Asynchronous lookup: checks local storage, then fetches from server API
export async function fetchBookById(id: string): Promise<PhotoBook | undefined> {
  // 1. Check local storage first
  const local = getBookById(id);
  if (local && local.pages && local.pages.length > 0 && !id.startsWith('book-wedding') && !id.startsWith('book-trip')) {
    return local;
  }

  // 2. Fetch from server API
  try {
    const res = await fetch(`/api/books/${encodeURIComponent(id)}`);
    if (res.ok) {
      const serverBook = await res.json();
      if (serverBook && serverBook.id) {
        // Save to local storage cache
        const allBooks = getAllStoredBooks();
        if (!allBooks.some(b => b.id === serverBook.id)) {
          allBooks.unshift(serverBook);
          localStorage.setItem(STORAGE_KEY_BOOKS, JSON.stringify(allBooks));
        }
        return serverBook;
      }
    }
  } catch (err) {
    console.warn('Could not fetch book from server:', err);
  }

  // 3. Fallback to local or sample books
  return local || SAMPLE_BOOKS.find(b => b.id === id);
}

export function getStoredLanguage(): string {
  try {
    return localStorage.getItem(STORAGE_KEY_LANG) || 'hinglish';
  } catch {
    return 'hinglish';
  }
}

export function saveStoredLanguage(lang: string) {
  try {
    localStorage.setItem(STORAGE_KEY_LANG, lang);
  } catch {
    //
  }
}

export function canUserCreateBook(user: UserProfile, books: PhotoBook[]): { allowed: boolean; remaining: number } {
  if (user.tier === 'pro') {
    return { allowed: true, remaining: 999 };
  }
  const maxAllowed = USAGE_LIMITS.maxFreeBooks + (user.bonusCredits || 0);
  const remaining = Math.max(0, maxAllowed - books.length);
  return {
    allowed: books.length < maxAllowed,
    remaining,
  };
}

export function canAddPageToBook(book: PhotoBook, user: UserProfile): { allowed: boolean; remaining: number } {
  if (user.tier === 'pro') {
    return { allowed: true, remaining: 999 };
  }
  const maxAllowed = USAGE_LIMITS.maxPagesPerBook;
  const currentCount = book.pages.length;
  const remaining = Math.max(0, maxAllowed - currentCount);
  return {
    allowed: currentCount < maxAllowed,
    remaining,
  };
}

// ---------------------------------------------------------------------------
// SHARE-LINK HELPERS (added)
// ---------------------------------------------------------------------------

const STORAGE_KEY_SHARED_CACHE = 'photobook_app_shared_cache_v1';
const STORAGE_KEY_PENDING_THEME = 'photobook_app_pending_share_theme_v1';

const sleep = (ms: number) => new Promise<void>((resolve) => setTimeout(resolve, ms));

// POST a book to the server (with timeout + retry). Returns true only when the server confirmed it.
const latestSyncSeq: Record<string, number> = {};

export async function syncBookToServer(book: PhotoBook, retries = 2): Promise<boolean> {
  const seq = (latestSyncSeq[book.id] || 0) + 1;
  latestSyncSeq[book.id] = seq;

  for (let attempt = 0; attempt <= retries; attempt++) {
    // A newer save of the same book has started: never let an older retry overwrite it
    if (latestSyncSeq[book.id] !== seq) return true;
    try {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 20000);
      const res = await fetch('/api/books', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(book),
        signal: controller.signal,
      });
      clearTimeout(timer);
      if (res.ok) return true;
      // Too large / bad payload will never succeed on retry
      if (res.status === 413 || res.status === 400) return false;
    } catch {
      // network error / timeout -> retry
    }
    if (attempt < retries) await sleep(1000 * (attempt + 1));
  }
  return false;
}

// Separate cache for books opened via someone else's link (never mixed with the user's own books)
function readSharedCache(): Record<string, PhotoBook> {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_SHARED_CACHE);
    const parsed = raw ? JSON.parse(raw) : {};
    return parsed && typeof parsed === 'object' ? parsed : {};
  } catch {
    return {};
  }
}

function writeSharedCache(book: PhotoBook) {
  try {
    const cache = readSharedCache();
    cache[book.id] = book;
    // keep cache small: only the 5 most recent shared books
    const ids = Object.keys(cache);
    if (ids.length > 5) delete cache[ids[0]];
    localStorage.setItem(STORAGE_KEY_SHARED_CACHE, JSON.stringify(cache));
  } catch {
    //
  }
}

export type SharedBookResult =
  | { status: 'ok'; book: PhotoBook }
  | { status: 'not-found' }
  | { status: 'error' };

// Opens a share link: the SERVER copy is always the source of truth, so the receiver sees exactly
// what the author saved (photos, layouts, styles, theme, title, description).
// Local copies are used only if the server cannot be reached.
export async function fetchSharedBook(id: string): Promise<SharedBookResult> {
  let reachedServer = false;

  for (let attempt = 0; attempt < 3; attempt++) {
    try {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 15000);
      const res = await fetch(`/api/books/${encodeURIComponent(id)}`, {
        cache: 'no-store',
        signal: controller.signal,
      });
      clearTimeout(timer);

      if (res.ok) {
        const serverBook = await res.json();
        if (serverBook && serverBook.id && Array.isArray(serverBook.pages)) {
          writeSharedCache(serverBook);
          return { status: 'ok', book: serverBook };
        }
      } else if (res.status === 404) {
        reachedServer = true;
        break;
      }
    } catch {
      // server may be waking up (cold start) -> retry
    }
    await sleep(1200 * (attempt + 1));
  }

  // Fallbacks (offline / server unreachable / book missing on server)
  const cached = readSharedCache()[id];
  if (cached && cached.pages && cached.pages.length > 0) return { status: 'ok', book: cached };

  const local = getBookById(id);
  if (local && local.pages && local.pages.length > 0) return { status: 'ok', book: local };

  return { status: reachedServer ? 'not-found' : 'error' };
}

// Theme of the shared book the visitor just viewed -> used when they create their own book
export function setPendingShareTheme(theme: string) {
  try {
    sessionStorage.setItem(STORAGE_KEY_PENDING_THEME, theme);
  } catch {
    //
  }
}

export function peekPendingShareTheme(): string | null {
  try {
    return sessionStorage.getItem(STORAGE_KEY_PENDING_THEME);
  } catch {
    return null;
  }
}

export function clearPendingShareTheme() {
  try {
    sessionStorage.removeItem(STORAGE_KEY_PENDING_THEME);
  } catch {
    //
  }
}
