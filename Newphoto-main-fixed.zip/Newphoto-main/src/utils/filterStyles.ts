import { PhotoFilter } from '../types';

export interface FilterMeta {
  id: PhotoFilter;
  label: string;
  hinglish: string;
  color: string;
  css: string;
  category: 'Popular' | 'Warm & Vintage' | 'Cool & Modern' | 'Artistic & B&W';
}

export const PHOTO_FILTERS: FilterMeta[] = [
  // --- TOP POPULAR & REQUESTED: WARM, COOL, VINTAGE, ORIGINAL ---
  { 
    id: 'normal', 
    label: 'Original Clean', 
    hinglish: 'Asli Photo', 
    color: '#94a3b8', 
    css: 'none',
    category: 'Popular',
  },
  { 
    id: 'warm', 
    label: 'Warm Golden Glow', 
    hinglish: 'Garam Sunehri Dhoop', 
    color: '#f59e0b', 
    css: 'sepia(28%) saturate(135%) contrast(106%) brightness(105%)',
    category: 'Warm & Vintage',
  },
  { 
    id: 'cool', 
    label: 'Cool Ocean Breeze', 
    hinglish: 'Thanda Neela Breeze', 
    color: '#06b6d4', 
    css: 'hue-rotate(20deg) saturate(118%) contrast(105%) brightness(102%)',
    category: 'Cool & Modern',
  },
  { 
    id: 'vintage', 
    label: '70s Film Vintage', 
    hinglish: 'Vintage 70s Nostalgia', 
    color: '#d97706', 
    css: 'sepia(45%) contrast(112%) saturate(125%) brightness(96%)',
    category: 'Warm & Vintage',
  },
  { 
    id: 'sepia', 
    label: 'Sepia Antique', 
    hinglish: 'Puraana Sepia Kagaz', 
    color: '#b45309', 
    css: 'sepia(85%) contrast(98%) brightness(95%)',
    category: 'Warm & Vintage',
  },
  { 
    id: 'golden', 
    label: 'Golden Hour Sunset', 
    hinglish: 'Sunehra Sham Hour', 
    color: '#fbbf24', 
    css: 'sepia(32%) saturate(175%) contrast(108%) brightness(106%)',
    category: 'Warm & Vintage',
  },
  { 
    id: 'amber', 
    label: 'Amber Fire', 
    hinglish: 'Kesar Amber Glow', 
    color: '#d97706', 
    css: 'sepia(40%) saturate(150%) hue-rotate(-8deg) contrast(115%)',
    category: 'Warm & Vintage',
  },
  { 
    id: 'retro-film', 
    label: 'Retro Kodak Grain', 
    hinglish: 'Kodak Film Look', 
    color: '#ea580c', 
    css: 'sepia(30%) contrast(118%) saturate(115%) brightness(102%)',
    category: 'Warm & Vintage',
  },
  { 
    id: 'peach', 
    label: 'Peach Bloom', 
    hinglish: 'Aadoo Peach Glow', 
    color: '#fb923c', 
    css: 'sepia(18%) saturate(130%) hue-rotate(345deg) brightness(106%)',
    category: 'Warm & Vintage',
  },
  { 
    id: 'sunset', 
    label: 'Twilight Sunset', 
    hinglish: 'Laal Sham Sunset', 
    color: '#ea580c', 
    css: 'sepia(35%) saturate(160%) hue-rotate(-12deg) contrast(110%)',
    category: 'Warm & Vintage',
  },
  { 
    id: 'polaroid', 
    label: '90s Instant Polaroid', 
    hinglish: '90s Polaroid Snap', 
    color: '#fdba74', 
    css: 'contrast(106%) brightness(110%) saturate(84%) sepia(20%)',
    category: 'Warm & Vintage',
  },

  // --- COOL & MODERN ---
  { 
    id: 'nordic', 
    label: 'Nordic Minimal', 
    hinglish: 'Nordic Saaf Clean', 
    color: '#67e8f9', 
    css: 'hue-rotate(15deg) contrast(105%) brightness(106%) saturate(92%)',
    category: 'Cool & Modern',
  },
  { 
    id: 'frost', 
    label: 'Arctic Frost', 
    hinglish: 'Baraf Thanda Chill', 
    color: '#38bdf8', 
    css: 'hue-rotate(175deg) saturate(112%) brightness(114%) contrast(96%)',
    category: 'Cool & Modern',
  },
  { 
    id: 'cinematic', 
    label: 'Cinematic Teal & Orange', 
    hinglish: 'Filmi Cinema Teal', 
    color: '#0284c7', 
    css: 'contrast(118%) saturate(125%) hue-rotate(185deg)',
    category: 'Cool & Modern',
  },
  { 
    id: 'emerald', 
    label: 'Emerald Forest', 
    hinglish: 'Panna Hara Jungle', 
    color: '#10b981', 
    css: 'hue-rotate(60deg) saturate(130%) contrast(105%)',
    category: 'Cool & Modern',
  },
  { 
    id: 'cyber', 
    label: 'Cyber Neon Glow', 
    hinglish: 'Cyberpunk Neon', 
    color: '#a855f7', 
    css: 'hue-rotate(270deg) saturate(175%) contrast(125%)',
    category: 'Cool & Modern',
  },
  { 
    id: 'lavender', 
    label: 'Lavender Dream', 
    hinglish: 'Lavender Haze', 
    color: '#c084fc', 
    css: 'hue-rotate(240deg) saturate(125%) brightness(108%)',
    category: 'Cool & Modern',
  },
  { 
    id: 'rose', 
    label: 'Rose Romance', 
    hinglish: 'Gulabi Ishq Rose', 
    color: '#ec4899', 
    css: 'hue-rotate(330deg) saturate(140%) brightness(105%)',
    category: 'Cool & Modern',
  },
  { 
    id: 'pastel', 
    label: 'Soft Pastel Fairy', 
    hinglish: 'Halka Komal Pastel', 
    color: '#f472b6', 
    css: 'saturate(85%) brightness(112%) contrast(92%)',
    category: 'Cool & Modern',
  },

  // --- ARTISTIC & B&W ---
  { 
    id: 'bw', 
    label: 'Classic Black & White', 
    hinglish: 'Black & White Sadabahaar', 
    color: '#475569', 
    css: 'grayscale(100%) contrast(120%)',
    category: 'Artistic & B&W',
  },
  { 
    id: 'noir', 
    label: 'High Contrast Noir', 
    hinglish: 'Gehra Kaala Noir', 
    color: '#0f172a', 
    css: 'grayscale(100%) contrast(165%) brightness(88%)',
    category: 'Artistic & B&W',
  },
  { 
    id: 'moody', 
    label: 'Moody Dramatic Dark', 
    hinglish: 'Gehra Moody Shadow', 
    color: '#334155', 
    css: 'brightness(88%) contrast(130%) saturate(85%)',
    category: 'Artistic & B&W',
  },
  { 
    id: 'matte', 
    label: 'Matte Gallery Print', 
    hinglish: 'Matte Print Art', 
    color: '#64748b', 
    css: 'contrast(92%) brightness(105%) saturate(90%)',
    category: 'Artistic & B&W',
  },
  { 
    id: 'chrome', 
    label: 'Silver Chrome Shine', 
    hinglish: 'Chandi Silvery Pop', 
    color: '#cbd5e1', 
    css: 'grayscale(55%) contrast(140%) brightness(110%)',
    category: 'Artistic & B&W',
  },
  { 
    id: 'vignette', 
    label: 'Dreamy Vignette', 
    hinglish: 'Sapno Jaisa Soft', 
    color: '#8b5cf6', 
    css: 'contrast(112%) brightness(96%) saturate(115%)',
    category: 'Artistic & B&W',
  },
  { 
    id: 'dramatic', 
    label: 'Dramatic Vivid HDR', 
    hinglish: 'Khatarnak Pop HDR', 
    color: '#e11d48', 
    css: 'contrast(145%) saturate(135%) brightness(98%)',
    category: 'Artistic & B&W',
  },
  { 
    id: 'fade', 
    label: 'Gentle Nostalgic Fade', 
    hinglish: 'Dheemi Yaadein Fade', 
    color: '#9ca3af', 
    css: 'contrast(85%) brightness(110%) saturate(75%)',
    category: 'Artistic & B&W',
  },
  { 
    id: 'vivid', 
    label: 'Ultra Vivid Color Pop', 
    hinglish: 'Rang-Biranga Ultra Pop', 
    color: '#f97316', 
    css: 'saturate(180%) contrast(115%) brightness(102%)',
    category: 'Popular',
  },
];

export function getPhotoFilterStyle(filter?: PhotoFilter): string {
  if (!filter) return 'none';
  const match = PHOTO_FILTERS.find(f => f.id === filter);
  return match ? match.css : 'none';
}
