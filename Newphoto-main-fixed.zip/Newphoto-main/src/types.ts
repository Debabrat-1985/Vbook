export type PageLayoutType = 
  | 'cover'
  | 'single-full'
  | 'round-center'
  | 'round-duo'
  | 'round-trio'
  | 'round-quad'
  | 'arch-portal'
  | 'arched-duo'
  | 'oval-portrait'
  | 'heart-frame'
  | 'star-crest'
  | 'diamond-center'
  | 'hex-cluster'
  | 'scalloped-badge'
  | 'organic-blob'
  | 'circle-caption'
  | 'polaroid-duo'
  | 'polaroid-trio'
  | 'filmstrip-3'
  | 'filmstrip-vertical'
  | 'stamp-vintage'
  | 'split-2-v'
  | 'split-2-h'
  | 'grid-3'
  | 'grid-4'
  | 'grid-6'
  | 'magazine-feature'
  | 'collage-asymmetric'
  | 'story-text'
  | 'back-cover';

export type PhotoFilter = 
  | 'normal' 
  | 'warm' 
  | 'cool' 
  | 'bw' 
  | 'sepia' 
  | 'vintage'
  | 'sunset'
  | 'emerald'
  | 'cyber'
  | 'moody'
  | 'cinematic'
  | 'rose'
  | 'noir'
  | 'pastel'
  | 'vignette'
  | 'chrome'
  | 'golden'
  | 'polaroid'
  | 'frost'
  | 'lavender'
  | 'matte'
  | 'dramatic'
  | 'fade'
  | 'vivid'
  | 'amber'
  | 'nordic'
  | 'peach'
  | 'retro-film';

export interface BookPhoto {
  id: string;
  url: string;
  caption?: string;
  filter?: PhotoFilter;
  scale?: number;
  fitMode?: 'contain' | 'cover';
}

export interface BookPage {
  id: string;
  pageNumber: number;
  layout: PageLayoutType;
  title?: string;
  subtitle?: string;
  notes?: string;
  photos: BookPhoto[];
  bgColor?: string;
}

export type ThemeCategory = 
  | 'Royal & Luxury'
  | 'Modern & Minimal'
  | 'Pastel & Romance'
  | 'Dark & Moody'
  | 'Nature & Earthy'
  | 'Festive & Vibrant'
  | 'Vintage & Retro';

export type BookTheme = string;

export interface BookThemeConfig {
  id: BookTheme;
  name: string;
  nameHinglish: string;
  category: ThemeCategory;
  coverBg: string;
  coverText: string;
  accentColor: string;
  pageBg: string;
  pageText: string;
  spineColor: string;
  fontFamily: string;
}

export interface PhotoBook {
  id: string;
  title: string;
  subtitle: string;
  authorName: string;
  authorEmail?: string;
  coverImage?: string;
  theme: BookTheme;
  createdAt: number;
  updatedAt: number;
  pages: BookPage[];
  isPublic?: boolean;
}

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  avatarUrl: string;
  isLoggedIn: boolean;
  tier: 'free' | 'pro';
  booksCreatedCount: number;
  bonusCredits: number;
}

export interface UsageLimitConfig {
  maxFreeBooks: number;
  maxPagesPerBook: number;
}

export type AppTab = 'home' | 'books' | 'templates' | 'profile';
export type AppLanguage = 'hinglish' | 'hindi' | 'english';
