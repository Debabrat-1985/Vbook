/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import { 
  Plus, 
  BookOpen, 
  Share2, 
  Edit3, 
  Eye, 
  Sparkles, 
  Trash2, 
  AlertCircle,
  ChevronRight,
  UserPlus,
  LogIn,
  Loader2,
  RefreshCw
} from 'lucide-react';

import { 
  PhotoBook, 
  UserProfile, 
  AppTab, 
  AppLanguage 
} from './types';
import { 
  getStoredBooks, 
  saveBook, 
  deleteBook, 
  getBookById, 
  fetchBookById,
  fetchSharedBook,
  setPendingShareTheme,
  peekPendingShareTheme,
  clearPendingShareTheme,
  getUserProfile, 
  saveUserProfile, 
  getStoredLanguage, 
  saveStoredLanguage, 
  canUserCreateBook, 
  SAMPLE_BOOKS,
  USAGE_LIMITS 
} from './utils/storage';
import { logoutUser } from './utils/auth';
import { getTranslation } from './i18n/translations';
import { THEME_CONFIGS } from './utils/themePresets';

// Components
import { AndroidFrame } from './components/AndroidFrame';
import { TopBar } from './components/TopBar';
import { BottomNav } from './components/BottomNav';
import { UsageLimitBanner } from './components/UsageLimitBanner';
import { FlipBookViewer } from './components/FlipBookViewer';
import { BookEditor } from './components/BookEditor';
import { ShareModal } from './components/ShareModal';
import { AuthModal } from './components/AuthModal';
import { TemplatesView } from './components/TemplatesView';
import { ProfileView } from './components/ProfileView';

// Reads ?share=<bookId> from the URL (used to open WhatsApp / shared links directly in preview mode)
function getShareIdFromUrl(): string | null {
  try {
    return new URLSearchParams(window.location.search).get('share');
  } catch {
    return null;
  }
}

export default function App() {
  const [user, setUser] = useState<UserProfile | null>(() => getUserProfile());
  const [books, setBooks] = useState<PhotoBook[]>(() => {
    const session = getUserProfile();
    return session ? getStoredBooks(session.email) : [];
  });
  const [lang, setLang] = useState<AppLanguage>('hinglish');
  const [currentTab, setCurrentTab] = useState<AppTab>('home');
  const [isOnline, setIsOnline] = useState(typeof navigator !== 'undefined' ? navigator.onLine : true);

  // Active view states
  const [activeBookId, setActiveBookId] = useState<string | null>(null);
  const [loadedSharedBook, setLoadedSharedBook] = useState<PhotoBook | null>(null);
  // If the app is opened from a share link, start directly in shared-preview (never flash the empty home screen)
  const [viewMode, setViewMode] = useState<'app' | 'editor' | 'preview' | 'shared-preview'>(
    () => (getShareIdFromUrl() ? 'shared-preview' : 'app')
  );
  const [sharedLoadStatus, setSharedLoadStatus] = useState<'idle' | 'loading' | 'not-found' | 'error'>(
    () => (getShareIdFromUrl() ? 'loading' : 'idle')
  );
  const [slideDirection, setSlideDirection] = useState<'right' | 'left'>('right');

  const navigateToView = (newMode: 'app' | 'editor' | 'preview' | 'shared-preview') => {
    const depthMap: Record<'app' | 'editor' | 'preview' | 'shared-preview', number> = {
      app: 0,
      editor: 1,
      preview: 2,
      'shared-preview': 2,
    };
    const currentDepth = depthMap[viewMode];
    const newDepth = depthMap[newMode];
    setSlideDirection(newDepth >= currentDepth ? 'right' : 'left');
    setViewMode(newMode);
  };
  
  // Modals
  const [sharingBook, setSharingBook] = useState<PhotoBook | null>(null);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [authModalMode, setAuthModalMode] = useState<'signup' | 'login'>('signup');
  const [limitAlertMessage, setLimitAlertMessage] = useState<string | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Show Toast
  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Loads the book of a share link from the server (always the latest saved version)
  const loadSharedBook = async (sharedId: string) => {
    setSharedLoadStatus('loading');
    const result = await fetchSharedBook(sharedId);
    if (result.status === 'ok') {
      setActiveBookId(result.book.id);
      setLoadedSharedBook(result.book);
      // Remember the theme the visitor just saw, so the book they create next uses the same theme
      setPendingShareTheme(result.book.theme);
      setSharedLoadStatus('idle');
      setViewMode('shared-preview');
    } else {
      setSharedLoadStatus(result.status);
    }
  };

  // Online / offline listeners & URL check for shared book
  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    const storedLang = getStoredLanguage() as AppLanguage;
    if (storedLang) setLang(storedLang);

    // Check URL query parameters for shared book links: ?share=<bookId>
    const params = new URLSearchParams(window.location.search);
    const sharedId = params.get('share');
    if (sharedId) {
      loadSharedBook(sharedId);
    }

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Sync books when user logs in or signs up
  const handleLoginSuccess = (loggedInUser: UserProfile) => {
    setUser(loggedInUser);
    const userBooks = getStoredBooks(loggedInUser.email);
    setBooks(userBooks);
    triggerToast(`Welcome, ${loggedInUser.name}!`);

    // If recipient signed up from shared preview, transition to app and create their book
    if (viewMode === 'shared-preview') {
      navigateToView('app');
      window.history.replaceState({}, '', window.location.pathname);
      setTimeout(() => {
        handleCreateNewBook(undefined, loggedInUser, userBooks);
      }, 150);
    }
  };

  const handleLogout = () => {
    logoutUser();
    setUser(null);
    setBooks([]);
    triggerToast('Aap log out ho chuke hain (Signed Out)');
  };

  // Language update
  const handleLanguageChange = (newLang: AppLanguage) => {
    setLang(newLang);
    saveStoredLanguage(newLang);
  };

  const openAuthWithMode = (mode: 'signup' | 'login' = 'signup') => {
    setAuthModalMode(mode);
    setShowAuthModal(true);
  };

  // Create New Photobook with login check & free limit check
  const handleCreateNewBook = (preset?: Partial<PhotoBook>, userOverride?: UserProfile, booksOverride?: PhotoBook[]) => {
    const activeUser = userOverride || user;
    // If not logged in, prompt user to sign up / log in directly
    if (!activeUser) {
      triggerToast('Pehle Sign Up ya Log In karein');
      openAuthWithMode('signup');
      return;
    }

    // Check if user is allowed to create more books
    const { allowed } = canUserCreateBook(activeUser, booksOverride || books);
    if (!allowed) {
      setLimitAlertMessage(getTranslation(lang, 'reachLimitDesc'));
      return;
    }

    const newBookId = `book-${Date.now()}`;
    // Theme of the shared book the visitor just viewed (falls back to the default theme)
    const sharedTheme = peekPendingShareTheme();
    const startTheme =
      preset?.theme ||
      (sharedTheme && THEME_CONFIGS[sharedTheme] ? sharedTheme : undefined) ||
      'blossom-pastel';
    const newBook: PhotoBook = {
      id: newBookId,
      title: preset?.title || 'My Precious Moments',
      subtitle: preset?.subtitle || 'Crafted with PhotoBook App',
      authorName: activeUser.name,
      authorEmail: activeUser.email,
      coverImage: preset?.coverImage || 'https://images.unsplash.com/photo-1519741497674-611481863552?w=800&auto=format&fit=crop&q=80',
      theme: startTheme,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      isPublic: true,
      pages: [
        {
          id: `p-cov-${Date.now()}`,
          pageNumber: 1,
          layout: 'cover',
          title: preset?.title || 'Our Sweet Memories',
          subtitle: 'A beautiful collection of timeless chapters',
          notes: 'Every picture tells an unforgettable story.',
          photos: [
            {
              id: `ph-1`,
              url: preset?.coverImage || 'https://images.unsplash.com/photo-1519741497674-611481863552?w=800&auto=format&fit=crop&q=80',
              caption: 'Special Day',
              filter: 'warm',
            }
          ]
        },
        {
          id: `p-2-${Date.now()}`,
          pageNumber: 2,
          layout: 'single-full',
          title: 'First Chapter & Smiles',
          subtitle: 'Where the journey started',
          notes: 'Cherishing these precious times.',
          photos: [
            {
              id: `ph-2`,
              url: 'https://images.unsplash.com/photo-1511285560929-80b456fea0bc?w=800&auto=format&fit=crop&q=80',
              caption: 'Pure happiness',
              filter: 'normal',
            }
          ]
        },
        {
          id: `p-back-${Date.now()}`,
          pageNumber: 3,
          layout: 'back-cover',
          title: 'Forever In Our Hearts',
          subtitle: 'The journey continues...',
          notes: 'Created on Android with PhotoBook.',
          photos: []
        }
      ]
    };

    const updated = saveBook(newBook);
    setBooks(updated);
    setActiveBookId(newBookId);
    clearPendingShareTheme();
    if (getShareIdFromUrl()) {
      window.history.replaceState({}, '', window.location.pathname);
    }
    navigateToView('editor');
    
    // Confetti celebration
    try {
      confetti({ particleCount: 50, spread: 60, origin: { y: 0.8 } });
    } catch {}

    triggerToast('New Photobook created!');
  };

  // Save book changes
  const handleSaveBook = (updatedBook: PhotoBook) => {
    const updated = saveBook(updatedBook);
    setBooks(updated);
  };

  // Delete book
  const handleDeleteBook = (id: string) => {
    if (window.confirm(getTranslation(lang, 'confirmDelete'))) {
      const updated = deleteBook(id, user?.email);
      setBooks(updated);
      if (activeBookId === id) {
        setActiveBookId(null);
        navigateToView('app');
      }
      triggerToast('Photobook deleted');
    }
  };

  // Claim bonus free book
  const handleClaimBonus = () => {
    if (!user) {
      openAuthWithMode('signup');
      return;
    }
    const updatedUser: UserProfile = {
      ...user,
      bonusCredits: (user.bonusCredits || 0) + 1,
    };
    setUser(updatedUser);
    saveUserProfile(updatedUser);
    try {
      confetti({ particleCount: 80, spread: 70, origin: { y: 0.6 } });
    } catch {}
    triggerToast('🎉 +1 Free Book unlocked! Enjoy your new album.');
    setLimitAlertMessage(null);
  };

  // Upgrade to Pro
  const handleUpgradePro = () => {
    if (!user) {
      openAuthWithMode('signup');
      return;
    }
    const updatedUser: UserProfile = {
      ...user,
      tier: 'pro',
    };
    setUser(updatedUser);
    saveUserProfile(updatedUser);
    try {
      confetti({ particleCount: 100, spread: 80, origin: { y: 0.5 } });
    } catch {}
    triggerToast('🌟 Pro VIP Unlocked! Unlimited photobooks enabled.');
    setLimitAlertMessage(null);
  };

  // Reset / Clear Data
  const handleResetData = () => {
    if (window.confirm('Kya aap saara data clear karna chahte hain?')) {
      if (user) {
        localStorage.removeItem('photobook_app_user_books_v2');
        setBooks([]);
      }
      triggerToast('Books cleared');
    }
  };

  // Active book lookup: prioritizes loaded shared book when in shared-preview mode
  const activeBook = (viewMode === 'shared-preview' && loadedSharedBook)
    ? loadedSharedBook
    : books.find(b => b.id === activeBookId) || getBookById(activeBookId || '') || SAMPLE_BOOKS[0];

  return (
    <AndroidFrame>
      <div className="flex-1 flex flex-col justify-between h-full relative overflow-hidden bg-slate-950 text-slate-100">
        
        {/* Top App Bar (rendered for app workspace and editor, FlipBookViewer has its own sleek integrated header) */}
        {viewMode !== 'preview' && viewMode !== 'shared-preview' && (
          <TopBar
            title={
              viewMode === 'editor'
                ? 'Edit Photobook'
                : undefined
            }
            showBack={viewMode !== 'app'}
            onBack={() => {
              navigateToView('app');
            }}
            lang={lang}
            onLanguageChange={handleLanguageChange}
            onOpenAuth={openAuthWithMode}
            user={user}
            isOnline={isOnline}
          />
        )}

        {/* VIEW 0: SHARED LINK LOADING / NOT FOUND (instead of showing the empty home screen) */}
        {viewMode === 'shared-preview' && !loadedSharedBook && (
          <div key="view-shared-loading" className="flex-1 min-h-0 flex flex-col items-center justify-center gap-4 p-6 text-center">
            {sharedLoadStatus === 'loading' || sharedLoadStatus === 'idle' ? (
              <>
                <Loader2 className="w-8 h-8 text-indigo-400 animate-spin" />
                <div>
                  <h3 className="text-sm font-bold text-white">Photobook khul rahi hai...</h3>
                  <p className="text-xs text-slate-400 mt-1">Ek second, book load ho rahi hai</p>
                </div>
              </>
            ) : (
              <>
                <div className="w-12 h-12 rounded-2xl bg-amber-500/15 text-amber-400 flex items-center justify-center">
                  <AlertCircle className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white">
                    {sharedLoadStatus === 'not-found' ? 'Ye photobook ab available nahi hai' : 'Photobook load nahi ho paayi'}
                  </h3>
                  <p className="text-xs text-slate-400 mt-1 max-w-[260px]">
                    {sharedLoadStatus === 'not-found'
                      ? 'Shayad owner ne ise delete kar diya hai. Aap apni khud ki photobook bana sakte hain!'
                      : 'Internet connection check karke dobara try karein.'}
                  </p>
                </div>
                <div className="flex flex-col gap-2 w-full max-w-[240px]">
                  <button
                    onClick={() => {
                      const id = getShareIdFromUrl();
                      if (id) loadSharedBook(id);
                    }}
                    className="py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 active:scale-95 transition"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>Dobara Try Karein</span>
                  </button>
                  <button
                    onClick={() => {
                      clearPendingShareTheme();
                      setSharedLoadStatus('idle');
                      navigateToView('app');
                      window.history.replaceState({}, '', window.location.pathname);
                    }}
                    className="py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs active:scale-95 transition"
                  >
                    PhotoBook App Kholein
                  </button>
                </div>
              </>
            )}
          </div>
        )}

        {/* VIEW 1: SHARED PREVIEW ONLY MODE (WHATSAPP SHARE LINK CLICKED) */}
        {viewMode === 'shared-preview' && loadedSharedBook && activeBook && (
          <div key="view-shared-preview" className={`flex-1 min-h-0 flex flex-col overflow-hidden ${slideDirection === 'right' ? 'view-slide-right' : 'view-slide-left'}`}>
            <FlipBookViewer
              book={activeBook}
              isSharedPreview={true}
              isLoggedIn={!!user}
              lang={lang}
              onBack={() => {
                clearPendingShareTheme();
                navigateToView('app');
                window.history.replaceState({}, '', window.location.pathname);
              }}
              onStartCreate={() => {
                if (user) {
                  handleCreateNewBook();
                } else {
                  openAuthWithMode('signup');
                }
              }}
              onOpenAuth={(mode) => {
                openAuthWithMode(mode);
              }}
            />
          </div>
        )}

        {/* VIEW 2: REGULAR PREVIEW (Author viewing flipbook) */}
        {viewMode === 'preview' && activeBook && (
          <div key="view-preview" className={`flex-1 min-h-0 flex flex-col overflow-hidden ${slideDirection === 'right' ? 'view-slide-right' : 'view-slide-left'}`}>
            <FlipBookViewer
              book={activeBook}
              isSharedPreview={false}
              lang={lang}
              onBack={() => navigateToView('app')}
              onEdit={() => navigateToView('editor')}
              onShare={() => setSharingBook(activeBook)}
              onStartCreate={() => navigateToView('editor')}
            />
          </div>
        )}

        {/* VIEW 3: EDITOR */}
        {viewMode === 'editor' && activeBook && user && (
          <div key="view-editor" className={`flex-1 flex flex-col overflow-hidden ${slideDirection === 'right' ? 'view-slide-right' : 'view-slide-left'}`}>
            <BookEditor
              book={activeBook}
              user={user}
              lang={lang}
              onSave={handleSaveBook}
              onPreview={() => navigateToView('preview')}
              onReachLimit={(msg) => setLimitAlertMessage(msg)}
            />
          </div>
        )}

        {/* VIEW 4: MAIN APP WORKSPACE WITH TABS */}
        {viewMode === 'app' && (
          <div key="view-app" className={`flex-1 flex flex-col min-h-0 overflow-hidden relative ${slideDirection === 'right' ? 'view-slide-right' : 'view-slide-left'}`}>
            <main className="flex-1 min-h-0 overflow-y-auto overscroll-contain">
            
            {/* TAB: HOME */}
            {currentTab === 'home' && (
              <div key="home-tab" className="tab-slide flex-1 p-3.5 flex flex-col gap-4 pb-28">
                
                {/* Greeting Banner */}
                <div>
                  <h2 className="text-lg font-bold text-white tracking-tight">
                    {user ? `Namaste, ${user.name}! 👋` : 'Welcome to PhotoBook! 👋'}
                  </h2>
                  <p className="text-xs text-slate-400">
                    {user ? getTranslation(lang, 'tagline') : 'Apna khud ka digital memory album banayein'}
                  </p>
                </div>

                {/* Free Tier Usage Meter or Sign Up Card */}
                <UsageLimitBanner
                  user={user}
                  books={books}
                  lang={lang}
                  onUpgradePrompt={() => handleUpgradePro()}
                  onClaimBonus={() => handleClaimBonus()}
                  onOpenAuth={() => openAuthWithMode('signup')}
                />

                {/* Primary Action Card */}
                <div className="p-4 rounded-3xl bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 shadow-xl shadow-indigo-600/20 text-white flex flex-col gap-3">
                  <div className="flex items-center justify-between">
                    <span className="px-2.5 py-0.5 rounded-full bg-white/20 text-[10px] font-bold tracking-wider uppercase">
                      New Album
                    </span>
                    <Sparkles className="w-4 h-4 text-yellow-300" />
                  </div>
                  <div>
                    <h3 className="text-base font-extrabold leading-tight">
                      {getTranslation(lang, 'createNewBookTitle')}
                    </h3>
                    <p className="text-xs text-indigo-100 mt-1 opacity-90">
                      Shaadi, Birthday, Vacation ya Dosti ki yaadon ko sundar 3D flipbook me sajayein.
                    </p>
                  </div>
                  <button
                    onClick={() => handleCreateNewBook()}
                    className="w-full py-2.5 px-4 rounded-2xl bg-white text-indigo-950 font-bold text-xs shadow-md hover:bg-indigo-50 active:scale-95 transition flex items-center justify-center gap-1.5"
                  >
                    <Plus className="w-4 h-4 text-indigo-600" />
                    <span>{user ? getTranslation(lang, 'createBook') : 'Sign Up & Create Book (Free)'}</span>
                  </button>
                </div>

                {/* Books List Section */}
                <div>
                  <div className="flex items-center justify-between mb-2.5">
                    <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                      {getTranslation(lang, 'myBooks')} ({books.length})
                    </h3>
                    {books.length > 0 && (
                      <button
                        onClick={() => setCurrentTab('books')}
                        className="text-xs text-indigo-400 font-semibold hover:underline flex items-center gap-0.5"
                      >
                        <span>View All</span>
                        <ChevronRight className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>

                  {books.length > 0 ? (
                    <div className="flex flex-col gap-2.5">
                      {books.map((b) => (
                        <div
                          key={b.id}
                          className="bg-slate-900 border border-slate-800 rounded-2xl p-3 flex items-center gap-3 shadow-md hover:border-slate-700 transition"
                        >
                          <div
                            onClick={() => {
                              setActiveBookId(b.id);
                              navigateToView('preview');
                            }}
                            className="w-16 h-20 rounded-xl overflow-hidden bg-slate-800 shrink-0 cursor-pointer relative group"
                          >
                            <img
                              src={b.pages[0]?.photos[0]?.url || b.coverImage}
                              alt={b.title}
                              className="w-full h-full object-contain bg-slate-900 p-0.5 group-hover:scale-102 transition"
                            />
                            <div className="absolute inset-0 bg-black/30 flex items-center justify-center opacity-0 group-hover:opacity-100 transition">
                              <Eye className="w-4 h-4 text-white" />
                            </div>
                          </div>

                          <div className="flex-1 min-w-0">
                            <h4
                              onClick={() => {
                                setActiveBookId(b.id);
                                navigateToView('preview');
                              }}
                              className="text-sm font-bold text-white truncate cursor-pointer hover:text-indigo-400"
                            >
                              {b.title}
                            </h4>
                            <p className="text-[11px] text-slate-400 truncate mt-0.5">{b.subtitle}</p>
                            <p className="text-[10px] text-indigo-400 mt-1">
                              {b.pages.length} Pages • Theme: {b.theme}
                            </p>
                          </div>

                          {/* Action Buttons */}
                          <div className="flex items-center gap-1 shrink-0">
                            <button
                              onClick={() => {
                                setActiveBookId(b.id);
                                navigateToView('editor');
                              }}
                              className="p-2 rounded-xl bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 transition"
                              title="Edit"
                            >
                              <Edit3 className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => setSharingBook(b)}
                              className="p-2 rounded-xl bg-indigo-600/30 text-indigo-300 hover:bg-indigo-600 hover:text-white transition"
                              title="Share Preview Link"
                            >
                              <Share2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    /* Clean empty state for new user */
                    <div className="bg-slate-900 border border-slate-800/80 rounded-2xl p-6 text-center flex flex-col items-center gap-2">
                      <div className="w-12 h-12 rounded-2xl bg-indigo-600/10 text-indigo-400 flex items-center justify-center">
                        <BookOpen className="w-6 h-6" />
                      </div>
                      <h4 className="text-sm font-bold text-white">Koi photobook nahi hai abhi</h4>
                      <p className="text-xs text-slate-400 max-w-[240px]">
                        Apni pehli photobook banayein ya ready-made template chunein!
                      </p>
                      <button
                        onClick={() => handleCreateNewBook()}
                        className="mt-2 py-2 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-md transition active:scale-95 flex items-center gap-1.5"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>Pehla Photobook Banayein</span>
                      </button>
                    </div>
                  )}
                </div>

                {/* Ready Made Templates Section */}
                <div className="mt-1">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-yellow-400" />
                      <span>Ready Made Templates</span>
                    </h3>
                    <button
                      onClick={() => setCurrentTab('templates')}
                      className="text-xs text-indigo-400 font-semibold hover:underline"
                    >
                      Explore All
                    </button>
                  </div>
                  <div
                    onClick={() => setCurrentTab('templates')}
                    className="p-3 rounded-2xl bg-slate-900 border border-slate-800/80 hover:border-indigo-500/50 cursor-pointer flex items-center gap-3 transition"
                  >
                    <div className="w-10 h-10 rounded-xl bg-indigo-600/20 text-indigo-400 flex items-center justify-center">
                      <BookOpen className="w-5 h-5" />
                    </div>
                    <div className="flex-1">
                      <h4 className="text-xs font-bold text-white">Shaadi, Travel & Birthday Presets</h4>
                      <p className="text-[10px] text-slate-400">Pre-configured photo grids, fonts and palettes</p>
                    </div>
                    <ChevronRight className="w-4 h-4 text-slate-500" />
                  </div>
                </div>
              </div>
            )}

            {/* TAB: MY BOOKS */}
            {currentTab === 'books' && (
              <div key="books-tab" className="tab-slide flex-1 p-3.5 flex flex-col gap-4 pb-28">
                <div className="flex items-center justify-between">
                  <div>
                    <h2 className="text-base font-bold text-white">
                      {getTranslation(lang, 'myBooks')}
                    </h2>
                    <p className="text-xs text-slate-400">Manage, edit and share your albums</p>
                  </div>
                  <button
                    onClick={() => handleCreateNewBook()}
                    className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-indigo-600 text-white text-xs font-bold shadow-md shadow-indigo-600/30 active:scale-95 transition"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>New Book</span>
                  </button>
                </div>

                {books.length > 0 ? (
                  <div className="flex flex-col gap-3">
                    {books.map((b) => (
                      <div
                        key={b.id}
                        className="bg-slate-900 border border-slate-800 rounded-3xl p-4 flex flex-col gap-3 shadow-lg"
                      >
                        <div className="flex items-center gap-3">
                          <img
                            src={b.pages[0]?.photos[0]?.url || b.coverImage}
                            alt={b.title}
                            className="w-16 h-20 rounded-xl object-contain bg-slate-950 p-0.5 border border-slate-800"
                          />
                          <div className="flex-1 min-w-0">
                            <h3 className="text-sm font-bold text-white truncate">{b.title}</h3>
                            <p className="text-xs text-slate-400 truncate mt-0.5">{b.subtitle}</p>
                            <div className="flex items-center gap-2 mt-2">
                              <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-800 text-slate-300">
                                {b.pages.length} Pages
                              </span>
                              <span className="text-[10px] px-2 py-0.5 rounded-full bg-indigo-950 text-indigo-300 border border-indigo-500/30">
                                {b.theme}
                              </span>
                            </div>
                          </div>
                        </div>

                        <div className="grid grid-cols-4 gap-1.5 pt-1 border-t border-slate-800/80">
                          <button
                            onClick={() => {
                              setActiveBookId(b.id);
                              navigateToView('preview');
                            }}
                            className="py-2 px-1 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center justify-center gap-1 transition"
                          >
                            <Eye className="w-3.5 h-3.5 text-indigo-400" />
                            <span>Preview</span>
                          </button>

                          <button
                            onClick={() => {
                              setActiveBookId(b.id);
                              navigateToView('editor');
                            }}
                            className="py-2 px-1 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center justify-center gap-1 transition"
                          >
                            <Edit3 className="w-3.5 h-3.5 text-emerald-400" />
                            <span>Edit</span>
                          </button>

                          <button
                            onClick={() => setSharingBook(b)}
                            className="py-2 px-1 rounded-xl bg-indigo-600/30 hover:bg-indigo-600 text-indigo-300 hover:text-white text-xs font-semibold flex items-center justify-center gap-1 transition"
                          >
                            <Share2 className="w-3.5 h-3.5" />
                            <span>Share</span>
                          </button>

                          <button
                            onClick={() => handleDeleteBook(b.id)}
                            className="py-2 px-1 rounded-xl bg-slate-800 hover:bg-rose-950/40 text-slate-400 hover:text-rose-400 text-xs font-semibold flex items-center justify-center gap-1 transition"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                            <span>Delete</span>
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="bg-slate-900 border border-slate-800 rounded-3xl p-8 text-center flex flex-col items-center gap-3">
                    <BookOpen className="w-10 h-10 text-indigo-400 opacity-60" />
                    <div>
                      <h3 className="text-sm font-bold text-white">Abhi koi photobook nahi hai</h3>
                      <p className="text-xs text-slate-400 mt-1 max-w-[240px]">
                        Apna pehla photobook create karein. Free plan me aap 2 books bilkul muft bana sakte hain!
                      </p>
                    </div>
                    <button
                      onClick={() => handleCreateNewBook()}
                      className="py-2.5 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-md transition active:scale-95 flex items-center gap-1.5"
                    >
                      <Plus className="w-4 h-4" />
                      <span>{getTranslation(lang, 'createBook')}</span>
                    </button>
                  </div>
                )}
              </div>
            )}

            {/* TAB: TEMPLATES */}
            {currentTab === 'templates' && (
              <div key="templates-tab" className="tab-slide flex-1">
                <TemplatesView
                  lang={lang}
                  onSelectTemplate={(tmpl) => handleCreateNewBook(tmpl)}
                />
              </div>
            )}

            {/* TAB: PROFILE */}
            {currentTab === 'profile' && (
              <div key="profile-tab" className="tab-slide flex-1">
                <ProfileView
                  user={user}
                  books={books}
                  lang={lang}
                  onLanguageChange={handleLanguageChange}
                  onOpenAuth={openAuthWithMode}
                  onLogout={handleLogout}
                  onUpgradePro={handleUpgradePro}
                  onClaimBonus={handleClaimBonus}
                  onResetData={handleResetData}
                  onShareApp={() => {
                    const shareUrl = window.location.origin;
                    navigator.clipboard.writeText(shareUrl);
                    triggerToast('App link copied! Share with your friends.');
                  }}
                />
              </div>
            )}
            </main>

            {/* Bottom Navigation */}
            <BottomNav
              currentTab={currentTab}
              onTabChange={setCurrentTab}
              lang={lang}
              booksCount={books.length}
            />
          </div>
        )}

        {/* MODAL 1: SHARE MODAL */}
        {sharingBook && (
          <ShareModal
            book={sharingBook}
            lang={lang}
            onClose={() => setSharingBook(null)}
            onOpenPreview={() => {
              setActiveBookId(sharingBook.id);
              setLoadedSharedBook(sharingBook);
              setPendingShareTheme(sharingBook.theme);
              navigateToView('shared-preview');
              setSharingBook(null);
            }}
          />
        )}

        {/* MODAL 2: AUTH MODAL (SIGN UP / LOG IN) */}
        <AuthModal
          isOpen={showAuthModal}
          onClose={() => setShowAuthModal(false)}
          user={user}
          lang={lang}
          initialMode={authModalMode}
          onLoginSuccess={handleLoginSuccess}
          onLogout={handleLogout}
        />

        {/* MODAL 3: USAGE LIMIT ALERT MODAL */}
        {limitAlertMessage && (
          <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex flex-col justify-end sm:items-center sm:justify-center p-3 animate-in fade-in">
            <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-md p-5 shadow-2xl flex flex-col gap-4 text-slate-100">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0">
                  <AlertCircle className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white">
                    {getTranslation(lang, 'reachLimitTitle')}
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">{limitAlertMessage}</p>
                </div>
              </div>

              <div className="flex flex-col gap-2 pt-2">
                <button
                  onClick={handleClaimBonus}
                  className="w-full py-2.5 rounded-xl bg-gradient-to-r from-pink-600 to-purple-600 text-white font-bold text-xs shadow-md shadow-pink-600/20 active:scale-95 transition"
                >
                  {getTranslation(lang, 'shareWithFriend')} (+1 Free Book)
                </button>
                <button
                  onClick={handleUpgradePro}
                  className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 font-bold text-xs border border-amber-500/30 transition"
                >
                  {getTranslation(lang, 'upgradeToPro')}
                </button>
                <button
                  onClick={() => setLimitAlertMessage(null)}
                  className="w-full py-2 text-xs text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        )}

        {/* FLOATING TOAST NOTIFICATION */}
        {toastMessage && (
          <div className="fixed bottom-20 left-1/2 -translate-x-1/2 z-50 bg-indigo-600 text-white px-4 py-2 rounded-full text-xs font-semibold shadow-xl shadow-indigo-900/50 flex items-center gap-2 animate-in fade-in slide-in-from-bottom-2">
            <Sparkles className="w-3.5 h-3.5 text-yellow-300" />
            <span>{toastMessage}</span>
          </div>
        )}
      </div>
    </AndroidFrame>
  );
}
